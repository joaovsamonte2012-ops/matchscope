# MatchScope V3 — dados reais

A V3 integra o app Android com a API-Football (API-Sports) por uma ponte nativa Java.

## Ativação no APK
1. Crie uma chave no painel da API-Football/API-Sports.
2. Abra MatchScope > Ajustes.
3. Cole a API key e toque em **Salvar e sincronizar**.
4. A chave fica salva no armazenamento privado do app Android.

## Dados usados
- `/fixtures?date=...` para agenda, status e placares.
- `/fixtures?id=...` para eventos, escalações e estatísticas da partida quando disponíveis.
- `/fixtures?team=...&last=5` para forma recente.
- `/standings` para classificação.

A camada nativa bloqueia endpoints de odds/bookmakers. O MatchScope usa os dados apenas para acompanhamento e análise esportiva.

## Atualização
- Home: a cada 90 segundos enquanto o app está aberto na data de hoje.
- Ao retornar ao app: sincronização silenciosa.
- Detalhes/estatísticas: ao abrir a partida.

A disponibilidade de estatísticas, escalações e outros campos depende da cobertura de cada competição pelo provedor.
