package com.matchscope.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService networkPool = Executors.newFixedThreadPool(3);
    private static final String API_BASE = "https://v3.football.api-sports.io";
    private static final String PREFS = "matchscope_prefs";
    private static final String API_KEY = "api_football_key";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 16, 31));
        getWindow().setNavigationBarColor(Color.rgb(8, 16, 31));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 16, 31));
        webView.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);

        webView.addJavascriptInterface(new NativeBridge(), "MatchScopeNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface public boolean hasApiKey() {
            return !getPreferences().isEmpty();
        }

        @JavascriptInterface public String getMaskedApiKey() {
            String key = getPreferences();
            if (key.isEmpty()) return "";
            if (key.length() <= 8) return "••••••••";
            return key.substring(0, 4) + "••••" + key.substring(key.length() - 4);
        }

        @JavascriptInterface public void setApiKey(String key) {
            String clean = key == null ? "" : key.trim();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(API_KEY, clean).apply();
        }

        @JavascriptInterface public void clearApiKey() {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(API_KEY).apply();
        }

        @JavascriptInterface public void apiRequest(String path, String requestId) {
            if (path == null || requestId == null) return;
            if (!isAllowedPath(path)) {
                deliver(requestId, 403, "{\"errors\":{\"request\":\"Endpoint nao permitido\"}}");
                return;
            }
            final String key = getPreferences();
            if (key.isEmpty()) {
                deliver(requestId, 401, "{\"errors\":{\"auth\":\"API key nao configurada\"}}");
                return;
            }
            networkPool.execute(() -> {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(API_BASE + path);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(18000);
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("x-apisports-key", key);
                    int code = conn.getResponseCode();
                    InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
                    StringBuilder body = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                    reader.close();
                    deliver(requestId, code, body.toString());
                } catch (Exception e) {
                    deliver(requestId, 0, "{\"errors\":{\"network\":" + JSONObject.quote(e.getMessage() == null ? "Falha de rede" : e.getMessage()) + "}}");
                } finally {
                    if (conn != null) conn.disconnect();
                }
            });
        }

        private boolean isAllowedPath(String path) {
            if (!path.startsWith("/")) return false;
            // MatchScope usa apenas dados esportivos. Rotas de odds/apostas ficam bloqueadas.
            if (path.contains("odds") || path.contains("bookmaker")) return false;
            return path.startsWith("/fixtures") || path.startsWith("/standings") || path.startsWith("/teams") || path.startsWith("/players") || path.startsWith("/leagues");
        }
    }

    private String getPreferences() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(API_KEY, "");
    }

    private void deliver(String requestId, int status, String body) {
        runOnUiThread(() -> {
            if (webView == null) return;
            String js = "window.__msNativeResolve(" + JSONObject.quote(requestId) + "," + status + "," + JSONObject.quote(body == null ? "" : body) + ");";
            webView.evaluateJavascript(js, null);
        });
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        networkPool.shutdownNow();
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
