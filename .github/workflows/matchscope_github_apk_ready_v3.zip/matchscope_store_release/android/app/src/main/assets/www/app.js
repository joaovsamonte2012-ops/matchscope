(() => {
  'use strict';

  const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
  const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':'&quot;'}[c]));
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const pct=n=>`${Math.round(n)}%`;
  const int=v=>Number.parseInt(String(v??'0').replace('%',''),10)||0;
  const num=v=>Number.parseFloat(String(v??'0').replace('%',''))||0;
  const fmtDate=d=>d.toISOString().slice(0,10);
  const tz='America/Sao_Paulo';

  const state={
    route:'home', tab:'summary', fixtureId:null, competition:null,
    dateOffset:0, filter:'all', query:'', loading:false, detailLoading:false,
    favorites:JSON.parse(localStorage.getItem('ms_favorites')||'[]'),
    fixtures:[], leagues:{}, teams:{}, details:{}, standings:{},
    liveConnected:false, lastSync:null, apiError:'', demo:false
  };

  const demoTeams={
    cam:{id:'cam',name:'Atlético-MG',short:'CAM',logo:'',color:'#151515'},fla:{id:'fla',name:'Flamengo',short:'FLA',logo:'',color:'#c91c28'},
    pal:{id:'pal',name:'Palmeiras',short:'PAL',logo:'',color:'#176b45'},cru:{id:'cru',name:'Cruzeiro',short:'CRU',logo:'',color:'#3156b7'}
  };
  const demoFixtures=[
    {id:'d1',leagueId:'bra',leagueName:'Brasileirão Série A',leagueCountry:'Brasil',leagueLogo:'',season:2026,round:'',date:new Date().toISOString(),status:'NS',elapsed:null,home:demoTeams.cam,away:demoTeams.fla,homeScore:null,awayScore:null},
    {id:'d2',leagueId:'bra',leagueName:'Brasileirão Série A',leagueCountry:'Brasil',leagueLogo:'',season:2026,round:'',date:new Date(Date.now()+7200000).toISOString(),status:'NS',elapsed:null,home:demoTeams.pal,away:demoTeams.cru,homeScore:null,awayScore:null}
  ];

  let reqSeq=0;
  const pending=new Map();
  window.__msNativeResolve=(id,status,body)=>{
    const p=pending.get(id); if(!p)return; pending.delete(id);
    try{ const data=JSON.parse(body||'{}'); status>=200&&status<300?p.resolve(data):p.reject({status,data}); }
    catch(e){p.reject({status,error:e});}
  };
  function nativeAvailable(){return !!window.MatchScopeNative && typeof window.MatchScopeNative.apiRequest==='function';}
  function hasKey(){try{return nativeAvailable()&&window.MatchScopeNative.hasApiKey();}catch(e){return false;}}
  function maskedKey(){try{return nativeAvailable()?window.MatchScopeNative.getMaskedApiKey():'';}catch(e){return '';}}
  function api(path){
    return new Promise((resolve,reject)=>{
      if(!nativeAvailable()) return reject({status:0,data:{errors:{native:'Abra pelo APK Android'}}});
      const id=`r${Date.now()}_${++reqSeq}`; pending.set(id,{resolve,reject});
      try{window.MatchScopeNative.apiRequest(path,id);}catch(e){pending.delete(id);reject(e);}
      setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject({status:0,data:{errors:{timeout:'Tempo limite da API'}}});}},22000);
    });
  }

  function dateForOffset(o){const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()+o);return d;}
  function brDate(d){return new Intl.DateTimeFormat('pt-BR',{timeZone:tz,day:'2-digit',month:'short'}).format(d).replace('.','');}
  function localTime(iso){try{return new Intl.DateTimeFormat('pt-BR',{timeZone:tz,hour:'2-digit',minute:'2-digit'}).format(new Date(iso));}catch(e){return '--:--';}}
  function dayLabel(o){if(o===0)return 'HOJE'; if(o===-1)return 'ONTEM'; if(o===1)return 'AMANHÃ'; return new Intl.DateTimeFormat('pt-BR',{weekday:'short',timeZone:tz}).format(dateForOffset(o)).replace('.','').toUpperCase();}
  function syncLabel(){if(state.loading)return 'Sincronizando…';if(!hasKey())return 'Modo demonstração';if(state.apiError)return 'Falha na sincronização';if(!state.lastSync)return 'Pronto para sincronizar';return `Atualizado ${new Intl.DateTimeFormat('pt-BR',{hour:'2-digit',minute:'2-digit'}).format(state.lastSync)}`;}

  function parseFixture(x){
    const f=x.fixture||{}, l=x.league||{}, th=x.teams?.home||{}, ta=x.teams?.away||{}, g=x.goals||{};
    const home={id:String(th.id),name:th.name||'Mandante',short:(th.name||'MAN').slice(0,3).toUpperCase(),logo:th.logo||'',winner:th.winner};
    const away={id:String(ta.id),name:ta.name||'Visitante',short:(ta.name||'VIS').slice(0,3).toUpperCase(),logo:ta.logo||'',winner:ta.winner};
    state.teams[home.id]=home; state.teams[away.id]=away;
    state.leagues[String(l.id)]={id:String(l.id),name:l.name||'Competição',country:l.country||'',logo:l.logo||'',flag:l.flag||'',season:l.season,standings:!!l.standings};
    return {id:String(f.id),leagueId:String(l.id),leagueName:l.name||'Competição',leagueCountry:l.country||'',leagueLogo:l.logo||'',season:l.season,round:l.round||'',date:f.date||'',status:f.status?.short||'NS',statusLong:f.status?.long||'',elapsed:f.status?.elapsed,extra:f.status?.extra,home,away,homeScore:g.home,awayScore:g.away,raw:x};
  }

  async function syncFixtures({silent=false}={}){
    if(!hasKey()){
      state.demo=true; state.fixtures=demoFixtures; state.apiError=''; render(); return;
    }
    state.demo=false; if(!silent)state.loading=true; state.apiError=''; render();
    try{
      const date=fmtDate(dateForOffset(state.dateOffset));
      const data=await api(`/fixtures?date=${date}&timezone=${encodeURIComponent(tz)}`);
      state.fixtures=(data.response||[]).map(parseFixture);
      state.liveConnected=true; state.lastSync=new Date();
    }catch(e){
      state.apiError=errorText(e); state.liveConnected=false;
      if(!state.fixtures.length){state.demo=true;state.fixtures=demoFixtures;}
    }finally{state.loading=false;render();}
  }

  function errorText(e){
    const errs=e?.data?.errors||{}; const vals=Object.values(errs);
    if(vals.length)return String(vals[0]);
    if(e?.status===401||e?.status===403)return 'Chave da API inválida ou sem permissão.';
    if(e?.status===429)return 'Limite de requisições atingido.';
    return 'Não foi possível atualizar os dados.';
  }

  function isLive(s){return ['1H','HT','2H','ET','BT','P','SUSP','INT','LIVE'].includes(s);}
  function isFinished(s){return ['FT','AET','PEN'].includes(s);}
  function statusText(m){if(isLive(m.status))return `${m.elapsed??''}${m.elapsed?"'":''}`||'AO VIVO';if(isFinished(m.status))return m.status;if(['PST','CANC','ABD'].includes(m.status))return m.status;return localTime(m.date);}
  function isFav(id){return state.favorites.includes(String(id));}
  function toggleFav(id){id=String(id);state.favorites=isFav(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];localStorage.setItem('ms_favorites',JSON.stringify(state.favorites));toast(isFav(id)?'Adicionado aos favoritos':'Removido dos favoritos');render();}
  function toast(msg){const r=$('#toast-root');if(!r)return;r.innerHTML=`<div class="toast">${esc(msg)}</div>`;setTimeout(()=>r.innerHTML='',1700);}
  function crest(t,lg=false){if(t?.logo)return `<img class="${lg?'crest-img-lg':'crest-img'}" src="${esc(t.logo)}" alt="${esc(t.name)}" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"/><span class="${lg?'crest-lg':'crest'} crest-fallback" style="display:none">${esc(t.short||'?')}</span>`;return `<span class="${lg?'crest-lg':'crest'}">${esc(t?.short||'?')}</span>`;}
  function leagueIcon(l){if(l?.logo)return `<img class="league-logo" src="${esc(l.logo)}" alt=""/>`;return '⚽';}

  function header({search=true}={}){return `<header class="topbar"><div class="brand-row"><div class="brand" data-route="home"><div class="brand-mark">M</div><div><div class="brand-title">MatchScope</div><div class="brand-sub">Futebol • dados • inteligência</div></div></div><div class="top-actions"><button class="icon-btn sync-dot ${state.liveConnected?'connected':''}" id="sync-now" aria-label="Sincronizar">↻</button><button class="icon-btn" data-route="settings" aria-label="Ajustes">⚙</button></div></div>${search?`<div class="search-wrap"><label class="searchbox"><span>⌕</span><input id="global-search" placeholder="Buscar time ou competição" value="${esc(state.query)}" /></label></div>`:''}</header>`;}
  function nav(){const items=[['home','▦','Jogos'],['live','●','Ao vivo'],['analysis','◈','Análises'],['competitions','◎','Competições'],['favorites','☆','Favoritos']];return `<nav class="bottom-nav"><div class="bottom-inner">${items.map(([r,i,l])=>`<button class="nav-btn ${state.route===r?'active':''}" data-route="${r}"><span class="nav-icon">${i}</span><span>${l}</span></button>`).join('')}</div></nav>`;}
  function shell(body,{search=true,navBar=true}={}){return `${header({search})}<main class="content">${body}</main>${navBar?nav():''}`;}
  function dateStrip(){return `<div class="date-strip">${[-2,-1,0,1,2].map(o=>{const d=dateForOffset(o);return `<button class="date-pill ${state.dateOffset===o?'active':''}" data-date="${o}"><div class="d1">${dayLabel(o)}</div><div class="d2">${String(d.getDate()).padStart(2,'0')}</div></button>`}).join('')}</div>`;}

  function filteredFixtures(){let rows=[...state.fixtures];if(state.filter==='live')rows=rows.filter(m=>isLive(m.status));if(state.filter==='finished')rows=rows.filter(m=>isFinished(m.status));if(state.filter==='upcoming')rows=rows.filter(m=>!isLive(m.status)&&!isFinished(m.status));const q=state.query.trim().toLowerCase();if(q)rows=rows.filter(m=>`${m.home.name} ${m.away.name} ${m.leagueName}`.toLowerCase().includes(q));return rows;}
  function groupByLeague(rows){const map=new Map();for(const m of rows){const k=m.leagueId;if(!map.has(k))map.set(k,[]);map.get(k).push(m);}return [...map.entries()];}
  function matchRow(m){const live=isLive(m.status), scoreH=m.homeScore??'–', scoreA=m.awayScore??'–';return `<article class="match-row show-fav" data-match="${m.id}"><div class="match-time ${live?'live':''}">${statusText(m)}</div><div class="teams"><div class="team-line">${crest(m.home)}<span class="team-name">${esc(m.home.name)}</span></div><div class="team-line">${crest(m.away)}<span class="team-name">${esc(m.away.name)}</span></div></div><div class="score-stack"><span>${scoreH}</span><span>${scoreA}</span></div><button class="fav-star icon-btn" data-fav="${m.id}">${isFav(m.id)?'★':'☆'}</button>${live?`<div class="match-insight"><span class="micro-tag"><strong>AO VIVO</strong> sincronizado</span><span class="micro-tag">${esc(m.round||'Partida')}</span></div>`:''}</article>`;}
  function leagueBlock(id,rows){const l=state.leagues[id]||{id,name:rows[0]?.leagueName||'Competição',country:rows[0]?.leagueCountry||'',logo:rows[0]?.leagueLogo||''};return `<section class="league-card card"><div class="league-head" data-competition="${esc(id)}"><div class="league-left"><div class="league-icon">${leagueIcon(l)}</div><div><div class="league-name">${esc(l.name)}</div><div class="league-country">${esc(l.country)}</div></div></div><div class="league-more">Tabela ›</div></div>${rows.map(matchRow).join('')}</section>`;}

  function home(){const rows=filteredFixtures(), groups=groupByLeague(rows);const liveCount=state.fixtures.filter(m=>isLive(m.status)).length;const body=`<section class="hero card"><div class="hero-kicker">Partidas reais</div><div class="hero-title">Seu futebol, com contexto.</div><div class="hero-copy">Escudos oficiais do provedor, placares sincronizados e análises próprias do MatchScope.</div><div class="hero-grid"><div class="hero-stat"><b>${state.fixtures.length}</b><span>jogos do dia</span></div><div class="hero-stat"><b>${liveCount}</b><span>ao vivo</span></div><div class="hero-stat"><b>${state.demo?'DEMO':'LIVE'}</b><span>fonte de dados</span></div></div></section>${dateStrip()}<div class="section-head"><div class="section-title">${brDate(dateForOffset(state.dateOffset))}</div><div class="section-note">${esc(syncLabel())}</div></div><div class="chips"><button class="chip ${state.filter==='all'?'active':''}" data-filter="all">Todos</button><button class="chip ${state.filter==='live'?'active':''}" data-filter="live">Ao vivo</button><button class="chip ${state.filter==='upcoming'?'active':''}" data-filter="upcoming">Próximos</button><button class="chip ${state.filter==='finished'?'active':''}" data-filter="finished">Encerrados</button></div>${state.apiError?`<div class="notice" style="margin:10px 0"><b>Sincronização:</b> ${esc(state.apiError)}</div>`:''}${state.loading?loadingCards():groups.length?groups.map(([id,r])=>leagueBlock(id,r)).join(''):`<div class="empty card"><div class="empty-icon">⚽</div><div class="empty-title">Nenhuma partida encontrada</div><div class="empty-copy">Altere a data ou o filtro.</div></div>`}`;return shell(body);}
  function loadingCards(){return `<div class="card skeleton" style="height:150px;margin-top:12px"></div><div class="card skeleton" style="height:210px;margin-top:12px"></div>`;}
  function live(){const old=state.filter;state.filter='live';const h=home();state.filter=old;return h;}

  function statMap(detail){const r=detail?.raw?.statistics||[];const out={};for(const side of r){const id=String(side.team?.id||'');out[id]={};for(const s of side.statistics||[])out[id][s.type]=s.value;}return out;}
  function statPair(detail,type){const sm=statMap(detail),m=detail.fixture;return [num(sm[m.home.id]?.[type]),num(sm[m.away.id]?.[type])];}
  function formFromFixtures(rows,teamId){return (rows||[]).slice(-5).map(x=>{const f=parseFixture(x),isH=f.home.id===String(teamId),gf=isH?f.homeScore:f.awayScore,ga=isH?f.awayScore:f.homeScore;if(gf==null||ga==null)return 0.5;return gf>ga?1:gf===ga?.5:0;});}
  function recentAverages(rows,teamId){let gf=0,ga=0,n=0,w=0,d=0;for(const x of rows||[]){const f=parseFixture(x);const isH=f.home.id===String(teamId);const a=isH?f.homeScore:f.awayScore,b=isH?f.awayScore:f.homeScore;if(a==null||b==null)continue;gf+=a;ga+=b;n++;if(a>b)w++;else if(a===b)d++;}return {gf:n?gf/n:1.2,ga:n?ga/n:1.2,form:n?(w+d*.5)/n:.5,n};}
  function poisson(lambda,k){let p=Math.exp(-lambda);for(let i=1;i<=k;i++)p*=lambda/i;return p;}
  function analysisFor(detail){
    const f=detail.fixture, shots=statPair(detail,'Total Shots'), on=statPair(detail,'Shots on Goal'), box=statPair(detail,'Shots insidebox'), poss=statPair(detail,'Ball Possession'), corners=statPair(detail,'Corner Kicks'), passes=statPair(detail,'Total passes'), accurate=statPair(detail,'Passes accurate'), saves=statPair(detail,'Goalkeeper Saves');
    const rh=recentAverages(detail.recentHome,f.home.id), ra=recentAverages(detail.recentAway,f.away.id);
    const threatH=clamp(on[0]*7+box[0]*3+shots[0]*1.4+corners[0]*2+poss[0]*.14,0,100), threatA=clamp(on[1]*7+box[1]*3+shots[1]*1.4+corners[1]*2+poss[1]*.14,0,100);
    const controlH=clamp(50+(poss[0]-poss[1])*.65+(passes[0]-passes[1])*.025,5,95);
    const effH=shots[0]?on[0]/shots[0]*100:0,effA=shots[1]?on[1]/shots[1]*100:0;
    const passH=passes[0]?accurate[0]/passes[0]*100:0,passA=passes[1]?accurate[1]/passes[1]*100:0;
    const live=isLive(f.status), elapsed=live?(f.elapsed||0):0, remain=live?clamp((90-elapsed)/90,.05,1):1;
    let lh=clamp((rh.gf*.55+ra.ga*.45)*1.08,.25,3.2), la=clamp((ra.gf*.55+rh.ga*.45)*.98,.25,3.0);
    if(live){lh=clamp((lh*.55+Math.max(.2,threatH/50)*.45)*remain,.08,2.5);la=clamp((la*.55+Math.max(.2,threatA/50)*.45)*remain,.08,2.5);}
    let hw=0,dr=0,aw=0,best=[0,0,0];const baseH=live?(f.homeScore||0):0,baseA=live?(f.awayScore||0):0;
    for(let i=0;i<=6;i++)for(let j=0;j<=6;j++){const p=poisson(lh,i)*poisson(la,j);const a=baseH+i,b=baseA+j;if(a>b)hw+=p;else if(a===b)dr+=p;else aw+=p;if(p>best[2])best=[a,b,p];}
    const total=hw+dr+aw||1;hw=hw/total*100;dr=dr/total*100;aw=aw/total*100;
    return {shots,on,box,poss,corners,passes,saves,threatH,threatA,controlH,effH,effA,passH,passA,rh,ra,hw,dr,aw,best,lh,la};
  }
  function formDots(form){return form.map(v=>`<span style="display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:4px;background:${v===1?'var(--success)':v===.5?'var(--warning)':'var(--muted-2)'}"></span>`).join('');}
  function statRow(name,a,b,suffix=''){const total=Math.abs(a)+Math.abs(b)||1;return `<div class="stat-row"><div class="v">${a}${suffix}</div><div class="mid">${esc(name)}</div><div class="v">${b}${suffix}</div><div class="stat-bars"><i style="width:${a/total*100}%;margin-left:auto"></i><i style="width:${b/total*100}%"></i></div></div>`;}

  async function loadDetail(id){
    if(state.details[id]?.loaded)return;
    state.detailLoading=true;render();
    const fixture=state.fixtures.find(x=>x.id===String(id));
    if(!fixture){state.detailLoading=false;return;}
    if(state.demo){state.details[id]={loaded:true,fixture,raw:{statistics:[],events:[],lineups:[]},recentHome:[],recentAway:[]};state.detailLoading=false;render();return;}
    try{
      const [d,h,a]=await Promise.all([
        api(`/fixtures?id=${encodeURIComponent(id)}&timezone=${encodeURIComponent(tz)}`),
        api(`/fixtures?team=${encodeURIComponent(fixture.home.id)}&last=5&timezone=${encodeURIComponent(tz)}`),
        api(`/fixtures?team=${encodeURIComponent(fixture.away.id)}&last=5&timezone=${encodeURIComponent(tz)}`)
      ]);
      const raw=d.response?.[0]||fixture.raw;const parsed=parseFixture(raw);
      state.details[id]={loaded:true,fixture:parsed,raw,recentHome:h.response||[],recentAway:a.response||[]};
      const idx=state.fixtures.findIndex(x=>x.id===String(id));if(idx>=0)state.fixtures[idx]=parsed;
    }catch(e){state.apiError=errorText(e);state.details[id]={loaded:true,fixture,raw:fixture.raw||{statistics:[],events:[],lineups:[]},recentHome:[],recentAway:[],partial:true};}
    finally{state.detailLoading=false;render();}
  }

  function matchPage(){const id=String(state.fixtureId||''), base=state.fixtures.find(x=>x.id===id);if(!base)return shell(`<div class="empty card"><div class="empty-title">Partida não encontrada</div></div>`,{search:false});const d=state.details[id];if(!d&&!state.detailLoading)setTimeout(()=>loadDetail(id),0);const f=d?.fixture||base;const tabs=[['summary','Resumo'],['stats','Estatísticas'],['analysis','Análise'],['lineups','Escalações'],['h2h','Forma']];let content=state.detailLoading&&!d?loadingCards():renderMatchTab(d||{fixture:f,raw:f.raw||{},recentHome:[],recentAway:[]});const body=`<div class="page-title-row"><button class="back-btn" data-route="home">‹</button><div><div class="page-title">${esc(f.leagueName)}</div><div class="page-sub">${esc(f.round||f.leagueCountry)}</div></div></div><section class="match-hero card"><div class="match-meta">${new Intl.DateTimeFormat('pt-BR',{timeZone:tz,dateStyle:'medium',timeStyle:'short'}).format(new Date(f.date))}</div><div class="scoreboard"><div class="team-hero">${crest(f.home,true)}<div class="team-hero-name">${esc(f.home.name)}</div></div><div><div class="big-score">${f.homeScore??'–'} <span style="color:var(--muted-2)">:</span> ${f.awayScore??'–'}</div><div class="score-status">${esc(statusText(f))}</div></div><div class="team-hero">${crest(f.away,true)}<div class="team-hero-name">${esc(f.away.name)}</div></div></div></section><div class="tabs">${tabs.map(([k,l])=>`<button class="tab ${state.tab===k?'active':''}" data-tab="${k}">${l}</button>`).join('')}</div>${content}`;return shell(body,{search:false});}

  function renderMatchTab(d){const f=d.fixture, raw=d.raw||{};if(state.tab==='summary'){
      const events=raw.events||[];return `<section class="card" style="padding:14px"><div class="section-title">Linha do tempo</div><div class="divider"></div>${events.length?`<div class="timeline">${events.slice().sort((a,b)=>(a.time?.elapsed||0)-(b.time?.elapsed||0)).map(e=>`<div class="event ${e.type==='Goal'?'goal':''}"><div class="event-time">${e.time?.elapsed||''}' ${esc(e.type||'')}</div><div class="event-text"><b>${esc(e.player?.name||e.team?.name||'Evento')}</b>${e.detail?` · ${esc(e.detail)}`:''}${e.assist?.name?` · assistência ${esc(e.assist.name)}`:''}</div></div>`).join('')}</div>`:`<div class="empty-copy">Os eventos aparecerão quando o provedor disponibilizar.</div>`}</section>`;
    }
    if(state.tab==='stats'){
      const a=analysisFor(d);return `<section class="card" style="padding:14px"><div class="section-title">Estatísticas da partida</div>${statRow('Posse',a.poss[0],a.poss[1],'%')}${statRow('Finalizações',a.shots[0],a.shots[1])}${statRow('No alvo',a.on[0],a.on[1])}${statRow('Dentro da área',a.box[0],a.box[1])}${statRow('Escanteios',a.corners[0],a.corners[1])}${statRow('Passes',a.passes[0],a.passes[1])}${statRow('Defesas',a.saves[0],a.saves[1])}</section>`;
    }
    if(state.tab==='analysis'){
      const a=analysisFor(d),fh=formFromFixtures(d.recentHome,f.home.id),fa=formFromFixtures(d.recentAway,f.away.id);return `<section class="hero card"><div class="hero-kicker">MatchScope Intelligence</div><div class="hero-title">Leitura profunda da partida</div><div class="hero-copy">Índices próprios calculados a partir de estatísticas reais e forma recente. Não são dados oficiais de xG.</div></section><div class="section-head" style="margin-top:14px"><div class="section-title">Cenários estatísticos</div></div><div class="prob-grid"><div class="prob ${a.hw>=a.dr&&a.hw>=a.aw?'primary':''}"><b>${pct(a.hw)}</b><span>${esc(f.home.name)}</span></div><div class="prob ${a.dr>=a.hw&&a.dr>=a.aw?'primary':''}"><b>${pct(a.dr)}</b><span>Equilíbrio</span></div><div class="prob ${a.aw>=a.hw&&a.aw>=a.dr?'primary':''}"><b>${pct(a.aw)}</b><span>${esc(f.away.name)}</span></div></div><div class="analysis-card card" style="margin-top:10px"><div class="analysis-top"><div><div class="analysis-title">Índice de ameaça</div><div class="analysis-desc">Combina chutes, chutes no alvo, ações dentro da área, escanteios e posse.</div></div><div class="analysis-score">${Math.round(a.threatH)}–${Math.round(a.threatA)}</div></div><div class="dual-meter"><div class="bar left"><i style="width:${a.threatH}%"></i></div><span>ameaça</span><div class="bar right"><i style="width:${a.threatA}%"></i></div></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Controle territorial</div><div class="analysis-desc">Posse e volume de passes apontam quem controla mais a partida.</div></div><div class="analysis-score">${Math.round(a.controlH)}%</div></div><div class="meter"><i style="width:${a.controlH}%"></i></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Eficiência de finalização</div><div class="analysis-desc">Percentual de finalizações que chegam ao alvo.</div></div><div class="analysis-score">${Math.round(a.effH)}% · ${Math.round(a.effA)}%</div></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Precisão de passe</div><div class="analysis-desc">Qualidade da circulação da bola.</div></div><div class="analysis-score">${Math.round(a.passH)}% · ${Math.round(a.passA)}%</div></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Forma recente</div><div class="analysis-desc">Últimos jogos disponíveis na API.</div></div><div class="analysis-score">${Math.round(a.rh.form*100)} · ${Math.round(a.ra.form*100)}</div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px"><div>${formDots(fh)}</div><div style="text-align:right">${formDots(fa)}</div></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Placar modal</div><div class="analysis-desc">Cenário individual de maior probabilidade no modelo Poisson ajustado pela forma e, quando ao vivo, pelo volume ofensivo atual.</div></div><div class="analysis-score">${a.best[0]}–${a.best[1]}</div></div></div><div class="notice"><b>Importante:</b> análise esportiva estatística. Os índices podem mudar conforme novos eventos e estatísticas chegam.</div>`;
    }
    if(state.tab==='lineups'){
      const ls=raw.lineups||[];return ls.length?ls.map(l=>`<section class="card" style="padding:14px;margin-bottom:10px"><div class="section-title">${esc(l.team?.name||'Time')} · ${esc(l.formation||'formação')}</div><div class="divider"></div>${(l.startXI||[]).map(p=>`<div class="settings-row"><div><div class="settings-title">${esc(p.player?.name||'Jogador')}</div><div class="settings-copy">${esc(p.player?.pos||'')} ${p.player?.number?`· #${p.player.number}`:''}</div></div></div>`).join('')}</section>`).join(''):`<div class="empty card"><div class="empty-title">Escalação ainda não disponível</div><div class="empty-copy">Normalmente aparece perto do início da partida, quando coberta pelo provedor.</div></div>`;
    }
    if(state.tab==='h2h'){
      const rh=(d.recentHome||[]).map(parseFixture),ra=(d.recentAway||[]).map(parseFixture);return `<div class="section-head"><div class="section-title">${esc(f.home.name)} · últimos jogos</div></div>${rh.length?rh.map(x=>matchRow(x)).join(''):`<div class="empty card"><div class="empty-copy">Sem histórico disponível.</div></div>`}<div class="section-head" style="margin-top:16px"><div class="section-title">${esc(f.away.name)} · últimos jogos</div></div>${ra.length?ra.map(x=>matchRow(x)).join(''):`<div class="empty card"><div class="empty-copy">Sem histórico disponível.</div></div>`}`;
    }
    return '';
  }

  function analysisHub(){const liveRows=state.fixtures.filter(m=>isLive(m.status));const rows=liveRows.length?liveRows:state.fixtures.slice(0,10);return shell(`<div class="page-title-row"><div><div class="page-title">Análises</div><div class="page-sub">Inteligência aplicada aos jogos reais</div></div></div><section class="hero card"><div class="hero-kicker">MatchScope</div><div class="hero-title">Muito além do placar.</div><div class="hero-copy">Abra uma partida para ver ameaça, controle, eficiência, forma recente e cenários estatísticos.</div></section><div class="section-head" style="margin-top:16px"><div class="section-title">Partidas para analisar</div><div class="section-note">${rows.length}</div></div>${rows.map(m=>`<div class="analysis-card card" data-match="${m.id}"><div class="analysis-top"><div><div class="analysis-title">${esc(m.home.name)} × ${esc(m.away.name)}</div><div class="analysis-desc">${esc(m.leagueName)} · ${statusText(m)}</div></div><div class="analysis-score">›</div></div></div>`).join('')||'<div class="empty card"><div class="empty-copy">Nenhum jogo carregado.</div></div>'}`);}

  function competitions(){const ls=Object.values(state.leagues);return shell(`<div class="page-title-row"><div><div class="page-title">Competições</div><div class="page-sub">Tabelas reais quando disponíveis</div></div></div><div class="comp-grid">${ls.map(l=>`<button class="comp-card card" data-competition="${l.id}" style="text-align:left;color:inherit;border:1px solid var(--line)"><div class="comp-flag">${leagueIcon(l)}</div><div class="comp-name">${esc(l.name)}</div><div class="comp-meta">${esc(l.country||'Internacional')}</div></button>`).join('')}</div>`);}
  async function loadStandings(l){if(state.standings[l.id]||state.demo||!l.season)return;try{const d=await api(`/standings?league=${encodeURIComponent(l.id)}&season=${encodeURIComponent(l.season)}`);state.standings[l.id]=d.response?.[0]?.league?.standings?.[0]||[];render();}catch(e){state.apiError=errorText(e);render();}}
  function competitionPage(){const l=state.leagues[String(state.competition)]||Object.values(state.leagues)[0];if(!l)return shell('<div class="empty card"><div class="empty-title">Competição não encontrada</div></div>',{search:false});if(!state.standings[l.id]&&!state.demo)setTimeout(()=>loadStandings(l),0);const t=state.standings[l.id]||[];const games=state.fixtures.filter(m=>m.leagueId===l.id);return shell(`<div class="page-title-row"><button class="back-btn" data-route="competitions">‹</button><div><div class="page-title">${esc(l.name)}</div><div class="page-sub">${esc(l.country||'')}</div></div></div>${t.length?`<section class="standings card"><div class="table-head"><span>#</span><span>Time</span><span>J</span><span>SG</span><span style="text-align:right">PTS</span></div>${t.map(r=>{const tm={id:String(r.team?.id),name:r.team?.name,short:(r.team?.name||'').slice(0,3).toUpperCase(),logo:r.team?.logo||''};return `<div class="table-row"><span class="rank ${r.rank<=4?'top':''}">${r.rank}</span><span class="table-team">${crest(tm)}<span class="team-name">${esc(tm.name)}</span></span><span>${r.all?.played??'-'}</span><span>${r.goalsDiff>0?'+':''}${r.goalsDiff??'-'}</span><span class="pts">${r.points??'-'}</span></div>`}).join('')}</section>`:`<div class="card skeleton" style="height:180px"></div>`}<div class="section-head" style="margin-top:16px"><div class="section-title">Jogos do dia</div></div>${games.length?leagueBlock(l.id,games):'<div class="empty card"><div class="empty-copy">Nenhum jogo desta competição na data selecionada.</div></div>'}`,{search:false});}

  function favorites(){const rows=state.fixtures.filter(m=>isFav(m.id));return shell(`<div class="page-title-row"><div><div class="page-title">Favoritos</div><div class="page-sub">Seus jogos salvos</div></div></div>${rows.length?groupByLeague(rows).map(([id,r])=>leagueBlock(id,r)).join(''):`<div class="empty card"><div class="empty-icon">☆</div><div class="empty-title">Nada favoritado ainda</div><div class="empty-copy">Toque na estrela de uma partida.</div></div>`}`);}

  function settings(){const configured=hasKey();return shell(`<div class="page-title-row"><button class="back-btn" data-route="home">‹</button><div><div class="page-title">Dados ao vivo</div><div class="page-sub">Conexão segura com API-Football</div></div></div><section class="card" style="padding:14px"><div class="settings-row"><div><div class="settings-title">Status</div><div class="settings-copy">${configured?'Chave configurada: '+esc(maskedKey()):'Nenhuma chave configurada'}</div></div><span class="badge ${configured?'live':''}">${configured?'CONECTADO':'DEMO'}</span></div><div class="field full" style="margin-top:12px"><label>API key</label><input id="api-key-input" type="password" placeholder="Cole sua chave API-Football" autocomplete="off" /></div><button class="primary-btn" id="save-api-key">Salvar e sincronizar</button>${configured?'<button class="secondary-btn" id="clear-api-key">Remover chave</button>':''}</section><div class="notice" style="margin-top:12px"><b>Como funciona:</b> a chave fica salva somente no armazenamento privado do aplicativo Android. O MatchScope não usa rotas de odds ou apostas.</div><section class="card" style="padding:14px;margin-top:12px"><div class="section-title">Sincronização</div><div class="divider"></div><div class="settings-row"><div><div class="settings-title">Jogos e placares</div><div class="settings-copy">Atualização automática enquanto o app está aberto.</div></div><span class="badge">90 s</span></div><div class="settings-row"><div><div class="settings-title">Estatísticas</div><div class="settings-copy">Carregadas ao abrir uma partida.</div></div><span class="badge">REAL</span></div><div class="settings-row"><div><div class="settings-title">Escudos</div><div class="settings-copy">Imagens fornecidas pela API para cada time.</div></div><span class="badge">REAL</span></div></section>`,{search:false,navBar:false});}

  function render(){const app=$('#app');if(!app)return;let h='';if(state.route==='home')h=home();else if(state.route==='live')h=live();else if(state.route==='match')h=matchPage();else if(state.route==='analysis')h=analysisHub();else if(state.route==='competitions')h=competitions();else if(state.route==='competition')h=competitionPage();else if(state.route==='favorites')h=favorites();else if(state.route==='settings')h=settings();else h=home();app.innerHTML=h;bind();}
  function go(r){state.route=r;if(r!=='match')state.tab='summary';history.pushState({route:r},'');window.scrollTo(0,0);render();}
  function bind(){
    $$('[data-route]').forEach(el=>el.onclick=()=>go(el.dataset.route));
    $$('[data-match]').forEach(el=>el.onclick=e=>{if(e.target.closest('[data-fav]'))return;state.fixtureId=el.dataset.match;state.route='match';state.tab='summary';history.pushState({route:'match',fixtureId:state.fixtureId},'');window.scrollTo(0,0);render();});
    $$('[data-fav]').forEach(el=>el.onclick=e=>{e.stopPropagation();toggleFav(el.dataset.fav);});
    $$('[data-filter]').forEach(el=>el.onclick=()=>{state.filter=el.dataset.filter;render();});
    $$('[data-date]').forEach(el=>el.onclick=()=>{state.dateOffset=Number(el.dataset.date);syncFixtures();});
    $$('[data-tab]').forEach(el=>el.onclick=()=>{state.tab=el.dataset.tab;render();});
    $$('[data-competition]').forEach(el=>el.onclick=()=>{state.competition=el.dataset.competition;state.route='competition';history.pushState({route:'competition',competition:state.competition},'');window.scrollTo(0,0);render();});
    const s=$('#global-search');if(s)s.oninput=()=>{state.query=s.value;clearTimeout(s._t);s._t=setTimeout(render,180);};
    const sync=$('#sync-now');if(sync)sync.onclick=()=>syncFixtures();
    const save=$('#save-api-key');if(save)save.onclick=()=>{const inp=$('#api-key-input'),k=inp?.value.trim();if(!k){toast('Cole sua API key');return;}try{window.MatchScopeNative.setApiKey(k);state.fixtures=[];state.details={};state.standings={};toast('Chave salva');state.route='home';syncFixtures();}catch(e){toast('Não foi possível salvar');}};
    const clear=$('#clear-api-key');if(clear)clear.onclick=()=>{try{window.MatchScopeNative.clearApiKey();}catch(e){}state.fixtures=demoFixtures;state.demo=true;state.details={};toast('Chave removida');render();};
  }

  history.replaceState({route:'home'},'');
  window.addEventListener('popstate',e=>{const x=e.state||{route:'home'};state.route=x.route||'home';state.fixtureId=x.fixtureId||state.fixtureId;state.competition=x.competition||state.competition;render();});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&hasKey()&&state.dateOffset===0)syncFixtures({silent:true});});
  setInterval(()=>{if(document.visibilityState==='visible'&&hasKey()&&state.dateOffset===0&&state.route!=='settings')syncFixtures({silent:true});},90000);
  state.fixtures=demoFixtures;
  render();
  setTimeout(()=>syncFixtures(),200);
})();
