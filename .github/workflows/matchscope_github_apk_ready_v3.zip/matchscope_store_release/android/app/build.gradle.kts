plugins { id("com.android.application") }

android {
    namespace = "com.matchscope.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.matchscope.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "3.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
