import os
import re
import shutil
from pathlib import Path

android_dir = Path(os.environ['ANDROID_DIR'])
repo_root = Path(os.environ.get('GITHUB_WORKSPACE', '.')).resolve()
bundle_dir = Path(os.environ.get('V23_BUNDLE_DIR', str(repo_root / '.v23'))).resolve()
www = android_dir / 'app/src/main/assets/www'
index = www / 'index.html'
if not index.exists():
    raise SystemExit('ERRO V23: index.html nao encontrado')


# Marca a compilacao como Beta 23 para facilitar atualizacao/diagnostico no Android.
gradle = android_dir / 'app/build.gradle.kts'
if gradle.exists():
    g = gradle.read_text(encoding='utf-8')
    g2 = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 23', g, count=1)
    g2 = re.sub(r'versionName\s*=\s*"[^"]*"', 'versionName = "0.23-beta"', g2, count=1)
    gradle.write_text(g2, encoding='utf-8')

# Copia a implementacao unificada do RPG e o sprite visual gerado.
for src_name, dst_name in [
    ('beta-rpg-v23.js', 'beta-rpg-v23.js'),
    ('beta-rpg-v23.css', 'beta-rpg-v23.css'),
]:
    src = bundle_dir / src_name
    dst = www / dst_name
    if not src.exists():
        raise SystemExit(f'ERRO V23: arquivo ausente: {src}')
    shutil.copy2(src, dst)

sprite = repo_root / '.github/assets/rpg-v23-sprite.jpg'
if not sprite.exists():
    raise SystemExit(f'ERRO V23: sprite ausente: {sprite}')
shutil.copy2(sprite, www / 'assets/rpg-v23-sprite.jpg')

# As camadas antigas competiam entre si e reescreviam #msProgScroll.
# Mantemos os patches antigos no build apenas para as correcoes nativas/Java,
# mas removemos os CSS/JS legados da pagina e deixamos o V23 ser o dono da UI RPG.
html = index.read_text(encoding='utf-8')
legacy = [
    'beta-progression.css', 'beta-progression.js',
    'beta-character-gender.css', 'beta-character-gender.js',
    'beta-cosmetics.css', 'beta-cosmetics.js',
    'beta-rpg-daily.css', 'beta-rpg-daily.js',
    'beta-hotfix.css', 'beta-hotfix.js',
]
for name in legacy:
    html = re.sub(r'<link[^>]+href=["\'][^"\']*' + re.escape(name) + r'(?:\?[^"\']*)?["\'][^>]*>\s*', '', html, flags=re.I)
    html = re.sub(r'<script[^>]+src=["\'][^"\']*' + re.escape(name) + r'(?:\?[^"\']*)?["\'][^>]*>\s*</script>\s*', '', html, flags=re.I)

# Evita duplicacao em rebuilds.
html = re.sub(r'<link[^>]+href=["\'][^"\']*beta-rpg-v23\.css(?:\?[^"\']*)?["\'][^>]*>\s*', '', html, flags=re.I)
html = re.sub(r'<script[^>]+src=["\'][^"\']*beta-rpg-v23\.js(?:\?[^"\']*)?["\'][^>]*>\s*</script>\s*', '', html, flags=re.I)
html = html.replace('</head>', '<link rel="stylesheet" href="beta-rpg-v23.css?v=23"></head>')
html = html.replace('</body>', '<script src="beta-rpg-v23.js?v=23"></script></body>')
index.write_text(html, encoding='utf-8')

# Validacoes fortes: o workflow falha antes de gerar um APK incompleto.
js = (www / 'beta-rpg-v23.js').read_text(encoding='utf-8')
css = (www / 'beta-rpg-v23.css').read_text(encoding='utf-8')
html = index.read_text(encoding='utf-8')
checks = {
    'V23 JS ligado': 'beta-rpg-v23.js?v=23' in html,
    'V23 CSS ligado': 'beta-rpg-v23.css?v=23' in html,
    'Sprite presente': (www / 'assets/rpg-v23-sprite.jpg').exists(),
    '24 itens RPG': js.count("rarity:") >= 24,
    'Inventario': "['inventory','Inventário']" in js,
    'Desafios': "['quests','Desafios']" in js,
    'Passe': "['pass','Passe']" in js,
    'Ranking': "['rank','Ranking']" in js,
    'Loja': "['store','Loja']" in js,
    'Equipar funcional': 'function equip(id)' in js,
    'Back funcional': 'window.MatchScoreBack=function()' in js,
    'Bottom nav removida': '.bottom-nav{display:none!important}' in css,
    'Menu perfil com rotas': 'data-v23-route' in js,
    'Sem RPG legado': not any(name in html for name in legacy),
}
for name, ok in checks.items():
    print(f'V23 {name}: {"OK" if ok else "FALHOU"}')
    if not ok:
        raise SystemExit(f'ERRO V23: validacao falhou: {name}')

print('MatchScore RPG V23 aplicado com sucesso.')
