package com.jv.capybaramacro;
import android.content.Context;import java.util.ArrayList;import java.util.List;
final class MacroStore {
 private static final String PREF="macro",KEY="steps";
 static List<MacroStep> load(Context c){List<MacroStep> out=new ArrayList<>();String raw=c.getSharedPreferences(PREF,0).getString(KEY,"");for(String item:raw.split(";")){MacroStep s=MacroStep.decode(item);if(s!=null)out.add(s);}return out;}
 static void add(Context c,MacroStep s){List<MacroStep> all=load(c);all.add(s);StringBuilder b=new StringBuilder();for(MacroStep x:all){if(b.length()>0)b.append(';');b.append(x.encode());}c.getSharedPreferences(PREF,0).edit().putString(KEY,b.toString()).apply();}
 static void clear(Context c){c.getSharedPreferences(PREF,0).edit().remove(KEY).apply();}
}
