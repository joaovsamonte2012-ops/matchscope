package com.jv.capybaramacro;
final class MacroStep {
 final float xRatio,yRatio; final long delayMs;
 MacroStep(float x,float y,long d){xRatio=x;yRatio=y;delayMs=d;}
 String encode(){return xRatio+","+yRatio+","+delayMs;}
 static MacroStep decode(String raw){String[] p=raw.split(",");if(p.length!=3)return null;try{return new MacroStep(Float.parseFloat(p[0]),Float.parseFloat(p[1]),Long.parseLong(p[2]));}catch(Exception e){return null;}}
}
