package com.jv.capybaramacro;
import android.accessibilityservice.AccessibilityService;import android.accessibilityservice.GestureDescription;import android.graphics.Path;import android.os.Handler;import android.os.Looper;import android.view.accessibility.AccessibilityEvent;import java.util.List;
public class MacroAccessibilityService extends AccessibilityService {
 static MacroAccessibilityService instance;private final Handler handler=new Handler(Looper.getMainLooper());private boolean running;private int index;
 @Override protected void onServiceConnected(){instance=this;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){}
 @Override public void onInterrupt(){stopMacro();}
 @Override public void onDestroy(){stopMacro();if(instance==this)instance=null;super.onDestroy();}
 boolean isRunning(){return running;}
 void startMacro(){if(running)return;running=true;index=0;handler.post(this::next);OverlayService.updateState("Rodando");}
 void stopMacro(){running=false;handler.removeCallbacksAndMessages(null);OverlayService.updateState("Parado");}
 private void next(){if(!running)return;if(getRootInActiveWindow()==null||!"com.habby.capybara".contentEquals(getRootInActiveWindow().getPackageName())){OverlayService.updateState("Abra o Capybara Go");handler.postDelayed(this::next,1000);return;}List<MacroStep> steps=MacroStore.load(this);if(steps.isEmpty()){running=false;OverlayService.updateState("Sem passos");return;}if(index>=steps.size())index=0;MacroStep s=steps.get(index++);int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels;Path p=new Path();p.moveTo(s.xRatio*w,s.yRatio*h);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,55)).build();dispatchGesture(g,null,null);OverlayService.updateState("Passo "+index+"/"+steps.size());handler.postDelayed(this::next,Math.max(250,s.delayMs));}
}
