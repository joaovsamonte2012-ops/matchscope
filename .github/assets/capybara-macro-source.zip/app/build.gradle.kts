plugins { id("com.android.application") }

android {
    namespace = "com.jv.capybaramacro"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.jv.capybaramacro"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
