# Política de Privacidade — modelo para personalização

> Este arquivo é um modelo inicial e deve ser revisado por um responsável jurídico antes de publicação comercial.

O MatchScope armazena nome, e-mail, senha em formato derivado/criptografado, histórico de análises, favoritos e preferências necessárias ao funcionamento do serviço. Senhas não são armazenadas em texto simples.

O aplicativo pode consumir dados esportivos de fornecedores externos configurados pelo operador. O MatchScope é um produto de análise esportiva e não executa apostas nem movimenta dinheiro relacionado a apostas.

Antes da publicação, inclua: identidade/contato do controlador, base legal aplicável, período de retenção, processo de exclusão de conta e dados, subprocessadores, política para menores, transferência internacional e canal de atendimento.
