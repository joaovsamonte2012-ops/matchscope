# Termos de Uso — modelo para personalização

> Modelo inicial. Revise juridicamente antes de vender ou publicar.

O MatchScope fornece estimativas estatísticas sobre futebol para fins informativos e educacionais. Projeções não garantem resultados esportivos. O serviço não oferece, intermedeia ou executa apostas.

O operador deve possuir direitos/licenças sobre marcas, imagens e dados usados no aplicativo. Recursos Premium representam acesso a funcionalidades do software e não promessa de resultado esportivo.
