# Checklist de publicação — MatchScope 1.0

## Produto
- [ ] Confirmar titular do nome/marca MatchScope.
- [ ] Definir URL pública do backend HTTPS.
- [ ] Contratar/licenciar fonte esportiva para uso comercial.
- [ ] Remover credenciais padrão e criar segredos de produção.
- [ ] Revisar Política de Privacidade e Termos com responsável legal.
- [ ] Disponibilizar página pública de privacidade e suporte.
- [ ] Testar exclusão de conta/dados antes da publicação.

## Google Play
- [ ] Abrir projeto `android/` no Android Studio atual.
- [ ] Instalar Android SDK 36 e Build Tools 36.0.0.
- [ ] Trocar `applicationId` caso já exista outro app com esse ID.
- [ ] Gerar chave de upload e configurar assinatura Release.
- [ ] Gerar Android App Bundle (.aab).
- [ ] Preencher Data Safety, classificação indicativa e conteúdo do app.
- [ ] Subir screenshots e ícone 512x512.

## App Store
- [ ] Abrir/criar projeto no Xcode 26+ usando os fontes de `ios/MatchScope/`.
- [ ] Definir Team e Bundle Identifier.
- [ ] Configurar signing/certificados Apple.
- [ ] Arquivar e enviar pelo Xcode para App Store Connect.
- [ ] Informar Privacy Policy URL e App Privacy.
- [ ] Inserir screenshots, suporte e dados para revisão.
