# MatchScope V2 — Relatório de testes

Data: 2026-09-09

## Testes executados
- `node --check web/app.js`: sintaxe JavaScript válida.
- Testes do motor analítico em Node: 8 partidas processadas; probabilidades de casa/empate/fora somam 100% dentro da tolerância.
- Parse do HTML e checagem de referências locais: aprovado.
- Manifesto PWA validado como JSON.
- Paridade de assets entre `web/`, Android (`assets/www`) e iOS (`www`): aprovada.
- Verificação de arquivos Android: `settings.gradle.kts`, `build.gradle.kts`, `AndroidManifest.xml`, `MainActivity.java` e `app/` presentes.
- Workflow GitHub Actions incluído para Android SDK 36 + Gradle 9.6 + Java 17.

## Fluxos funcionais implementados
Home, filtros, busca, ao vivo demonstrativo, favoritos persistentes, detalhes da partida, abas de resumo/estatísticas/análise/escalações/H2H, competições, classificação, central de análises e laboratório manual.

## Limitação conhecida
Este ambiente não possui o Android SDK/Gradle completo para produzir e instalar o APK localmente. A compilação final deve ser feita pelo GitHub Actions (o mesmo método que já funcionou no repositório do usuário). A interface usa dados locais de demonstração; placares reais automáticos exigem um provedor/API esportiva.
