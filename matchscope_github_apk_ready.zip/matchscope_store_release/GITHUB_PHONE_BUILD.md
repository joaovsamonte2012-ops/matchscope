# Gerar o MatchScope.apk pelo celular com GitHub Actions

O projeto já contém `.github/workflows/build-android-apk.yml`.

## Primeira vez
1. No GitHub pelo navegador do celular, crie um repositório vazio chamado `matchscope`.
2. Envie todo o conteúdo desta pasta para a raiz do repositório, preservando a pasta `.github`.
3. Abra a aba **Actions** do repositório.
4. Abra **Build Android APK**.
5. Toque em **Run workflow** e confirme em **Run workflow**.
6. Quando a execução ficar verde, abra-a e, na seção **Artifacts**, baixe `MatchScope-Android-APK`.
7. Extraia o ZIP do artifact. Dentro dele estará `MatchScope-debug.apk`.
8. Toque no APK no Android e autorize a instalação de apps dessa fonte, caso o sistema peça.

## Builds seguintes
Qualquer alteração enviada às pastas `android/` ou ao próprio workflow dispara uma nova compilação. Também é possível usar **Run workflow** manualmente.

## Publicação
O APK debug serve para testar no telefone. Para Google Play, o ideal é gerar um Android App Bundle (`.aab`) de release assinado pela conta de publicação.
