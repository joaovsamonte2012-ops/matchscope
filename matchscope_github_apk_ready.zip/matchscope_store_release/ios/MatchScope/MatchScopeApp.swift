import SwiftUI

@main
struct MatchScopeApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
