from __future__ import annotations
import asyncio, base64, hashlib, hmac, json, math, os, random, secrets, sqlite3, time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from fastapi import FastAPI, HTTPException, Request as FRequest
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "matchscope.db"
SECRET = os.getenv("MATCHSCOPE_SECRET", "change-this-secret-before-production")
ADMIN_EMAIL = os.getenv("MATCHSCOPE_ADMIN_EMAIL", "admin@matchscope.local").lower()
ADMIN_PASSWORD = os.getenv("MATCHSCOPE_ADMIN_PASSWORD", "MatchScope2026!")
FOOTBALL_DATA_TOKEN = os.getenv("FOOTBALL_DATA_TOKEN", "").strip()
SYNC_MINUTES = max(10, int(os.getenv("MATCHSCOPE_SYNC_MINUTES", "30")))


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def hash_password(password: str, salt: Optional[str] = None):
    salt_b = base64.urlsafe_b64decode(salt.encode()) if salt else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt_b, 210_000)
    return base64.urlsafe_b64encode(salt_b).decode(), base64.urlsafe_b64encode(digest).decode()


def verify_password(password, salt, expected):
    _, got = hash_password(password, salt)
    return hmac.compare_digest(got, expected)


def sign_token(user_id: int, ttl_days=30):
    payload = {"uid": user_id, "exp": int(time.time()) + ttl_days * 86400}
    body = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).hexdigest()
    return f"{body}.{sig}"


def parse_token(token: str):
    try:
        body, sig = token.split(".", 1)
        expected = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected): return None
        padded = body + "=" * ((4 - len(body) % 4) % 4)
        p = json.loads(base64.urlsafe_b64decode(padded).decode())
        if p["exp"] < time.time(): return None
        return int(p["uid"])
    except Exception:
        return None


def user_from_request(req: FRequest, required=True):
    auth = req.headers.get("authorization", "")
    uid = parse_token(auth[7:]) if auth.lower().startswith("bearer ") else None
    if not uid:
        if required: raise HTTPException(401, "Faça login para continuar")
        return None
    with db() as con:
        row = con.execute("SELECT id,name,email,is_admin,is_premium,created_at FROM users WHERE id=?", (uid,)).fetchone()
    if not row and required: raise HTTPException(401, "Sessão inválida")
    return dict(row) if row else None


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, salt TEXT NOT NULL, is_admin INTEGER DEFAULT 0,
          is_premium INTEGER DEFAULT 0, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS competitions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id TEXT, code TEXT UNIQUE NOT NULL,
          name TEXT NOT NULL, country TEXT, emblem TEXT
        );
        CREATE TABLE IF NOT EXISTS teams(
          id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id TEXT UNIQUE, name TEXT NOT NULL,
          short_name TEXT, crest TEXT, country TEXT, rating REAL DEFAULT 1500,
          form REAL DEFAULT 1.5, gf REAL DEFAULT 1.3, ga REAL DEFAULT 1.3
        );
        CREATE TABLE IF NOT EXISTS matches(
          id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id TEXT UNIQUE, competition_code TEXT,
          competition_name TEXT, utc_date TEXT NOT NULL, status TEXT DEFAULT 'SCHEDULED',
          home_team_id INTEGER, away_team_id INTEGER, home_name TEXT NOT NULL, away_name TEXT NOT NULL,
          home_score INTEGER, away_score INTEGER, venue TEXT, source TEXT DEFAULT 'demo', updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS analyses(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, match_id INTEGER,
          home_name TEXT NOT NULL, away_name TEXT NOT NULL, payload TEXT NOT NULL,
          result TEXT NOT NULL, favorite INTEGER DEFAULT 0, created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS notifications(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL,
          body TEXT NOT NULL, read INTEGER DEFAULT 0, created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
        """)
        # Admin
        if not con.execute("SELECT 1 FROM users WHERE email=?", (ADMIN_EMAIL,)).fetchone():
            salt, ph = hash_password(ADMIN_PASSWORD)
            con.execute("INSERT INTO users(name,email,password_hash,salt,is_admin,is_premium,created_at) VALUES(?,?,?,?,1,1,?)",
                        ("Administrador", ADMIN_EMAIL, ph, salt, now_iso()))
        # Seed demo competitions / teams / matches
        seeds_comp = [("BSB","Brasileirão Série A","Brasil"),("SUD","Copa Sul-Americana","América do Sul"),("CDB","Copa do Brasil","Brasil")]
        for code,name,country in seeds_comp:
            con.execute("INSERT OR IGNORE INTO competitions(code,name,country) VALUES(?,?,?)", (code,name,country))
        teams = [
            ("demo-atm","Atlético-MG","CAM",1630,1.78,1.52,1.13),
            ("demo-san","Santos","SAN",1570,1.57,1.39,1.26),
            ("demo-pal","Palmeiras","PAL",1740,2.02,1.82,.88),
            ("demo-fla","Flamengo","FLA",1760,2.08,1.91,.86),
            ("demo-gre","Grêmio","GRE",1530,1.35,1.25,1.41),
            ("demo-vas","Vasco","VAS",1505,1.28,1.18,1.47),
            ("demo-spf","São Paulo","SAO",1580,1.55,1.34,1.19),
            ("demo-boc","Boca Juniors","BOC",1660,1.77,1.45,1.02),
        ]
        for pid,name,short,rating,form,gf,ga in teams:
            con.execute("INSERT OR IGNORE INTO teams(provider_id,name,short_name,country,rating,form,gf,ga) VALUES(?,?,?,'Brasil',?,?,?,?)",
                        (pid,name,short,rating,form,gf,ga))
        if con.execute("SELECT COUNT(*) c FROM matches").fetchone()[0] == 0:
            today = datetime.now(timezone.utc).date()
            demos=[
                ("SUD","Copa Sul-Americana",0,"Atlético-MG","Santos",19),
                ("CDB","Copa do Brasil",1,"Atlético-MG","Grêmio",21),
                ("BSB","Brasileirão Série A",2,"Palmeiras","Flamengo",20),
                ("SUD","Copa Sul-Americana",3,"Boca Juniors","São Paulo",21),
            ]
            for i,(cc,cn,dd,h,a,hour) in enumerate(demos):
                dt=datetime.combine(today+timedelta(days=dd), datetime.min.time(), tzinfo=timezone.utc)+timedelta(hours=hour+3)
                con.execute("INSERT INTO matches(provider_id,competition_code,competition_name,utc_date,status,home_name,away_name,source,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                            (f"demo-{i}",cc,cn,dt.isoformat(),"SCHEDULED",h,a,"demo",now_iso()))
        con.commit()


def poisson(lam,k): return math.exp(-lam)*(lam**k)/math.factorial(k)
def clamp(v,a,b): return max(a,min(b,v))

def analyze_model(d: dict, simulations: int=10000):
    base_h=(d["gfH"]+d["gaA"])/2; base_a=(d["gfA"]+d["gaH"])/2
    gap=clamp((d["ratingH"]-d["ratingA"])/400,-1.2,1.2); formgap=clamp((d["formH"]-d["formA"])/3,-.6,.6)
    hf=1 if d.get("neutral") else 1.12; af=1 if d.get("neutral") else .92
    xh=clamp(base_h*hf*(1+.13*gap+.08*formgap),.2,3.8)
    xa=clamp(base_a*af*(1-.10*gap-.06*formgap),.2,3.8)
    home=draw=away=0.0; scores=[]
    for h in range(9):
        for a in range(9):
            p=poisson(xh,h)*poisson(xa,a); scores.append((h,a,p))
            if h>a: home+=p
            elif h==a: draw+=p
            else: away+=p
    total=home+draw+away; home/=total; draw/=total; away/=total
    scores.sort(key=lambda x:x[2], reverse=True)
    sim_h=sim_d=sim_a=0
    # deterministic-ish Monte Carlo per request while still stochastic
    for _ in range(simulations):
        hg=poisson_random(xh); ag=poisson_random(xa)
        if hg>ag: sim_h+=1
        elif hg==ag: sim_d+=1
        else: sim_a+=1
    spread=max(home,draw,away)-min(home,draw,away)
    confidence="Baixa" if spread<.14 else "Média" if spread<.28 else "Alta"
    insights=[]
    if not d.get("neutral"): insights.append(f"O mando de campo aumenta a projeção ofensiva de {d['home']}.")
    if abs(d['ratingH']-d['ratingA'])>=80: insights.append(f"O rating geral favorece {d['home'] if d['ratingH']>d['ratingA'] else d['away']}.")
    if abs(d['formH']-d['formA'])>=.35: insights.append(f"A forma recente favorece {d['home'] if d['formH']>d['formA'] else d['away']}.")
    if xh+xa<2.25: insights.append("A projeção aponta tendência de jogo mais fechado.")
    elif xh+xa>3.0: insights.append("A projeção aponta potencial de jogo aberto e maior produção ofensiva.")
    insights.append("As probabilidades são estimativas estatísticas e não garantem o resultado.")
    return {
        "home":round(home*100,1),"draw":round(draw*100,1),"away":round(away*100,1),
        "xh":round(xh,2),"xa":round(xa,2),"confidence":confidence,
        "scores":[{"score":f"{h} × {a}","p":round(p*100,1)} for h,a,p in scores[:6]],
        "sim":{"h":sim_h,"d":sim_d,"a":sim_a,"n":simulations},"insights":insights,
        "model_version":"MS-Poisson-2.0"
    }

def poisson_random(lam):
    L=math.exp(-lam); k=0; p=1.0
    while p>L:
        k+=1; p*=random.random()
    return k-1


def fetch_json(url, headers=None):
    req=Request(url, headers=headers or {})
    with urlopen(req, timeout=12) as r:
        return json.loads(r.read().decode())


def sync_football_data(days=5):
    if not FOOTBALL_DATA_TOKEN: return {"ok":False,"message":"FOOTBALL_DATA_TOKEN não configurado","imported":0}
    start=datetime.now(timezone.utc).date(); end=start+timedelta(days=days)
    url="https://api.football-data.org/v4/matches?"+urlencode({"dateFrom":start.isoformat(),"dateTo":end.isoformat()})
    data=fetch_json(url,{"X-Auth-Token":FOOTBALL_DATA_TOKEN})
    imported=0
    with db() as con:
        for m in data.get("matches",[]):
            comp=m.get("competition") or {}; home=m.get("homeTeam") or {}; away=m.get("awayTeam") or {}
            cc=comp.get("code") or f"FD{comp.get('id','X')}"
            con.execute("INSERT OR IGNORE INTO competitions(provider_id,code,name,country,emblem) VALUES(?,?,?,?,?)",
                        (str(comp.get("id","")),cc,comp.get("name","Competição"),(m.get("area") or {}).get("name"),comp.get("emblem")))
            for t in (home,away):
                if t.get("id"):
                    con.execute("INSERT OR IGNORE INTO teams(provider_id,name,short_name,crest,country) VALUES(?,?,?,?,?)",
                                (str(t["id"]),t.get("name") or t.get("shortName"),t.get("shortName"),t.get("crest"),(m.get("area") or {}).get("name")))
            hs=(m.get("score") or {}).get("fullTime",{}).get("home"); as_=(m.get("score") or {}).get("fullTime",{}).get("away")
            con.execute("""INSERT INTO matches(provider_id,competition_code,competition_name,utc_date,status,home_name,away_name,home_score,away_score,venue,source,updated_at)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                         ON CONFLICT(provider_id) DO UPDATE SET status=excluded.status,home_score=excluded.home_score,away_score=excluded.away_score,updated_at=excluded.updated_at""",
                        (str(m.get("id")),cc,comp.get("name"),m.get("utcDate"),m.get("status","SCHEDULED"),home.get("name"),away.get("name"),hs,as_,m.get("venue"),"football-data.org",now_iso()))
            imported+=1
        con.commit()
    return {"ok":True,"message":"Sincronização concluída","imported":imported}

async def auto_sync_loop():
    while True:
        try:
            if FOOTBALL_DATA_TOKEN: await asyncio.to_thread(sync_football_data, 5)
        except Exception as e:
            print("auto-sync:",e)
        await asyncio.sleep(SYNC_MINUTES*60)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db(); task=asyncio.create_task(auto_sync_loop())
    yield
    task.cancel()

app=FastAPI(title="MatchScope API",version="2.0",lifespan=lifespan)

class AuthIn(BaseModel):
    email:str; password:str=Field(min_length=6); name:Optional[str]=None
class AnalyzeIn(BaseModel):
    home:str; away:str; ratingH:float; ratingA:float; formH:float; formA:float; gfH:float; gfA:float; gaH:float; gaA:float; neutral:bool=False; match_id:Optional[int]=None
class PremiumIn(BaseModel): enabled:bool
class ReadNotifIn(BaseModel): ids:list[int]=[]

@app.post('/api/auth/register')
def register(x:AuthIn):
    email=x.email.strip().lower(); name=(x.name or email.split('@')[0]).strip()[:50]
    if '@' not in email: raise HTTPException(400,'E-mail inválido')
    salt,ph=hash_password(x.password)
    try:
        with db() as con:
            cur=con.execute("INSERT INTO users(name,email,password_hash,salt,created_at) VALUES(?,?,?,?,?)",(name,email,ph,salt,now_iso())); con.commit(); uid=cur.lastrowid
    except sqlite3.IntegrityError: raise HTTPException(409,'Este e-mail já está cadastrado')
    return {"token":sign_token(uid)}

@app.post('/api/auth/login')
def login(x:AuthIn):
    with db() as con: row=con.execute("SELECT * FROM users WHERE email=?",(x.email.strip().lower(),)).fetchone()
    if not row or not verify_password(x.password,row['salt'],row['password_hash']): raise HTTPException(401,'E-mail ou senha incorretos')
    return {"token":sign_token(row['id'])}

@app.get('/api/me')
def me(req:FRequest): return user_from_request(req)

@app.get('/api/dashboard')
def dashboard(req:FRequest, date:Optional[str]=None):
    user=user_from_request(req,False)
    day=date or datetime.now(timezone.utc).date().isoformat()
    with db() as con:
        matches=[dict(r) for r in con.execute("SELECT * FROM matches WHERE substr(utc_date,1,10)=? ORDER BY utc_date",(day,)).fetchall()]
        if not matches:
            matches=[dict(r) for r in con.execute("SELECT * FROM matches ORDER BY utc_date LIMIT 12").fetchall()]
        comps=[dict(r) for r in con.execute("SELECT * FROM competitions ORDER BY name").fetchall()]
        hist=0; fav=0; unread=0
        if user:
            hist=con.execute("SELECT COUNT(*) FROM analyses WHERE user_id=?",(user['id'],)).fetchone()[0]
            fav=con.execute("SELECT COUNT(*) FROM analyses WHERE user_id=? AND favorite=1",(user['id'],)).fetchone()[0]
            unread=con.execute("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read=0",(user['id'],)).fetchone()[0]
    return {"date":day,"matches":matches,"competitions":comps,"stats":{"analyses":hist,"favorites":fav,"unread":unread},"provider":{"live":bool(FOOTBALL_DATA_TOKEN),"name":"football-data.org" if FOOTBALL_DATA_TOKEN else "Modo demo"}}

@app.get('/api/matches')
def matches(date:Optional[str]=None, competition:Optional[str]=None):
    q="SELECT * FROM matches WHERE 1=1"; args=[]
    if date: q+=" AND substr(utc_date,1,10)=?"; args.append(date)
    if competition: q+=" AND competition_code=?"; args.append(competition)
    q+=" ORDER BY utc_date LIMIT 100"
    with db() as con: return [dict(r) for r in con.execute(q,args).fetchall()]

@app.get('/api/competitions')
def competitions():
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM competitions ORDER BY name").fetchall()]

@app.get('/api/competitions/{code}')
def competition_detail(code:str):
    with db() as con:
        comp=con.execute("SELECT * FROM competitions WHERE code=?",(code,)).fetchone()
        if not comp: raise HTTPException(404,'Competição não encontrada')
        ms=[dict(r) for r in con.execute("SELECT * FROM matches WHERE competition_code=? ORDER BY utc_date LIMIT 50",(code,)).fetchall()]
    return {"competition":dict(comp),"matches":ms}

@app.get('/api/teams')
def teams():
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM teams ORDER BY rating DESC,name").fetchall()]

@app.get('/api/teams/{team_id}')
def team_detail(team_id:int):
    with db() as con:
        t=con.execute("SELECT * FROM teams WHERE id=?",(team_id,)).fetchone()
        if not t: raise HTTPException(404,'Time não encontrado')
        ms=[dict(r) for r in con.execute("SELECT * FROM matches WHERE home_name=? OR away_name=? ORDER BY utc_date DESC LIMIT 12",(t['name'],t['name'])).fetchall()]
    return {"team":dict(t),"matches":ms}

@app.get('/api/matches/{match_id}/preset')
def match_preset(match_id:int):
    with db() as con:
        m=con.execute("SELECT * FROM matches WHERE id=?",(match_id,)).fetchone()
        if not m: raise HTTPException(404,'Jogo não encontrado')
        h=con.execute("SELECT * FROM teams WHERE name=?",(m['home_name'],)).fetchone(); a=con.execute("SELECT * FROM teams WHERE name=?",(m['away_name'],)).fetchone()
    def stats(t): return dict(rating=t['rating'],form=t['form'],gf=t['gf'],ga=t['ga']) if t else dict(rating=1500,form=1.5,gf=1.3,ga=1.3)
    return {"match":dict(m),"home":stats(h),"away":stats(a)}

@app.post('/api/analyze')
def analyze(x:AnalyzeIn, req:FRequest):
    user=user_from_request(req,False); d=x.model_dump(); sims=50000 if user and user['is_premium'] else 10000
    result=analyze_model(d,sims)
    if user:
        with db() as con:
            con.execute("INSERT INTO analyses(user_id,match_id,home_name,away_name,payload,result,created_at) VALUES(?,?,?,?,?,?,?)",
                        (user['id'],x.match_id,x.home,x.away,json.dumps(d),json.dumps(result),now_iso())); con.commit()
    return {"result":result,"saved":bool(user),"premium_simulations":sims}

@app.get('/api/history')
def history(req:FRequest):
    u=user_from_request(req)
    with db() as con: rows=con.execute("SELECT id,match_id,home_name,away_name,result,favorite,created_at FROM analyses WHERE user_id=? ORDER BY id DESC LIMIT 100",(u['id'],)).fetchall()
    out=[]
    for r in rows:
        d=dict(r); d['result']=json.loads(d['result']); out.append(d)
    return out

@app.post('/api/history/{analysis_id}/favorite')
def favorite(analysis_id:int, req:FRequest):
    u=user_from_request(req)
    with db() as con:
        r=con.execute("SELECT favorite FROM analyses WHERE id=? AND user_id=?",(analysis_id,u['id'])).fetchone()
        if not r: raise HTTPException(404,'Análise não encontrada')
        val=0 if r['favorite'] else 1; con.execute("UPDATE analyses SET favorite=? WHERE id=?",(val,analysis_id)); con.commit()
    return {"favorite":bool(val)}

@app.get('/api/notifications')
def notifications(req:FRequest):
    u=user_from_request(req)
    with db() as con: return [dict(r) for r in con.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50",(u['id'],)).fetchall()]

@app.post('/api/notifications/read')
def notifications_read(x:ReadNotifIn, req:FRequest):
    u=user_from_request(req)
    with db() as con:
        if x.ids:
            marks=','.join('?' for _ in x.ids); con.execute(f"UPDATE notifications SET read=1 WHERE user_id=? AND id IN ({marks})",[u['id'],*x.ids])
        else: con.execute("UPDATE notifications SET read=1 WHERE user_id=?",(u['id'],))
        con.commit()
    return {"ok":True}

@app.post('/api/notifications/test')
def notifications_test(req:FRequest):
    u=user_from_request(req)
    with db() as con:
        con.execute("INSERT INTO notifications(user_id,title,body,created_at) VALUES(?,?,?,?)",(u['id'],'MatchScope','Notificações ativadas. Você receberá alertas dentro do aplicativo.',now_iso())); con.commit()
    return {"ok":True}

@app.get('/api/admin/overview')
def admin_overview(req:FRequest):
    u=user_from_request(req)
    if not u['is_admin']: raise HTTPException(403,'Acesso restrito ao administrador')
    with db() as con:
        users=[dict(r) for r in con.execute("SELECT id,name,email,is_admin,is_premium,created_at FROM users ORDER BY id DESC LIMIT 100").fetchall()]
        metrics={"users":con.execute('SELECT COUNT(*) FROM users').fetchone()[0],"premium":con.execute('SELECT COUNT(*) FROM users WHERE is_premium=1').fetchone()[0],"analyses":con.execute('SELECT COUNT(*) FROM analyses').fetchone()[0],"matches":con.execute('SELECT COUNT(*) FROM matches').fetchone()[0]}
    return {"metrics":metrics,"users":users,"provider":{"configured":bool(FOOTBALL_DATA_TOKEN),"sync_minutes":SYNC_MINUTES}}

@app.post('/api/admin/users/{uid}/premium')
def set_premium(uid:int,x:PremiumIn,req:FRequest):
    u=user_from_request(req)
    if not u['is_admin']: raise HTTPException(403,'Acesso restrito')
    with db() as con: con.execute("UPDATE users SET is_premium=? WHERE id=?",(1 if x.enabled else 0,uid)); con.commit()
    return {"ok":True}

@app.post('/api/admin/sync')
def admin_sync(req:FRequest):
    u=user_from_request(req)
    if not u['is_admin']: raise HTTPException(403,'Acesso restrito')
    try: return sync_football_data(5)
    except Exception as e: raise HTTPException(502,f'Falha ao sincronizar: {e}')

@app.get('/api/provider/status')
def provider_status(): return {"configured":bool(FOOTBALL_DATA_TOKEN),"provider":"football-data.org","mode":"live" if FOOTBALL_DATA_TOKEN else "demo"}

# Static frontend
app.mount('/assets', StaticFiles(directory=ROOT/'assets'), name='assets')
@app.get('/')
def index(): return FileResponse(ROOT/'index.html')
@app.get('/app.js')
def js(): return FileResponse(ROOT/'app.js',media_type='application/javascript')
@app.get('/styles.css')
def css(): return FileResponse(ROOT/'styles.css',media_type='text/css')
@app.get('/manifest.webmanifest')
def manifest(): return FileResponse(ROOT/'manifest.webmanifest',media_type='application/manifest+json')
@app.get('/sw.js')
def sw(): return FileResponse(ROOT/'sw.js',media_type='application/javascript')

if __name__=='__main__':
    import uvicorn
    uvicorn.run('server:app',host='0.0.0.0',port=int(os.getenv('PORT','8000')),reload=False)
