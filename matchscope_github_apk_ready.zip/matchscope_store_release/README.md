# MatchScope V2

Aplicativo móvel de acompanhamento e análise de futebol, com interface própria inspirada nos padrões modernos de apps esportivos.

## O que já funciona offline
- Home com jogos por competição e filtros
- Ao vivo demonstrativo, próximos e encerrados
- Busca por time/competição
- Favoritos persistentes no aparelho
- Tela detalhada de partida
- Estatísticas, eventos, escalações e H2H
- Análises: força ofensiva, pressão, controle, intensidade, forma e momentum
- Modelo estatístico Poisson para cenários de resultado
- Laboratório manual de análise sem internet
- Competições e classificação
- Navegação mobile e PWA

## Dados
A V2 vem com um conjunto local de demonstração para funcionar imediatamente sem internet. Isso permite testar toda a experiência e o motor analítico. Placares reais automáticos exigem conectar um provedor/API esportiva; a interface foi construída para essa etapa sem precisar ser refeita.

## Android
O projeto Android fica em `android/` e empacota a interface em `app/src/main/assets/www/`.

## Segurança/escopo
O MatchScope é um app de informação e estatística esportiva. Não inclui odds, apostas, depósitos ou recomendações financeiras.
