# MatchScope Store Release 1.0

Pacote de produção de um aplicativo de **análise esportiva de futebol**. Não contém odds, links para casas de aposta, depósitos, carteira, execução de apostas ou integração com serviços de apostas.

## Pastas
- `android/`: projeto Android nativo, API 36.
- `ios/`: projeto Xcode/SwiftUI para iPhone.
- `backend/`: API FastAPI, autenticação, banco, sincronização e painel administrativo.
- `web/`: frontend/PWA.
- `store/`: ícones, feature graphic, textos e rascunhos de privacidade das lojas.

## Execução mobile sem servidor
As versões Android/iOS incluem `native-adapter.js`. Sem um backend configurado, o app funciona em modo local com dados de demonstração, análise estatística, histórico e favoritos armazenados no aparelho.

## Produção com nuvem
Hospede `backend/` em HTTPS e configure a fonte esportiva licenciada. Em seguida, defina `window.MATCHSCOPE_API_BASE` no `index.html` embarcado nas versões mobile para a URL da API antes do build final.

## Publicação
O código está preparado para geração dos binários de loja, mas os binários assinados não podem ser incluídos sem:
- chave de upload/assinatura da conta Google Play;
- certificado, provisioning profile e Team da conta Apple Developer;
- macOS + Xcode para compilar/assinar iOS.

Veja `BUILD_AND_RELEASE.md` e `PUBLISHING_CHECKLIST.md`.


## Gerar APK pelo celular

O projeto inclui GitHub Actions em `.github/workflows/build-android-apk.yml`. Depois de enviar o projeto a um repositório GitHub, abra **Actions > Build Android APK > Run workflow**. O APK aparecerá em **Artifacts** como `MatchScope-Android-APK`. Veja `GITHUB_PHONE_BUILD.md`.
