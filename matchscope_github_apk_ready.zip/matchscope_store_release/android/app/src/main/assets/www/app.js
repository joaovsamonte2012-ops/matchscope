(() => {
  'use strict';

  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => [...root.querySelectorAll(sel)];
  const clamp = (n,a,b)=>Math.max(a,Math.min(b,n));
  const pct = n => `${Math.round(n)}%`;
  const round = (n,d=1)=>Number(n).toFixed(d);
  const esc = s => String(s ?? '').replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':'&quot;'}[c]));

  const COLORS = ['#22c55e','#3b82f6','#ef4444','#f59e0b','#8b5cf6','#06b6d4','#ec4899','#64748b','#14b8a6','#eab308'];
  const state = {
    route: 'home',
    matchId: null,
    competitionId: null,
    tab: 'summary',
    dateIndex: 0,
    filter: 'all',
    query: '',
    favorites: JSON.parse(localStorage.getItem('ms_favorites') || '[]'),
    theme: localStorage.getItem('ms_theme') || 'dark',
    compact: localStorage.getItem('ms_compact') !== '0',
    demo: true
  };

  const leagues = [
    {id:'bra',name:'Brasileirão Série A',country:'Brasil',flag:'🇧🇷'},
    {id:'eng',name:'Premier League',country:'Inglaterra',flag:'🏴'},
    {id:'esp',name:'LaLiga',country:'Espanha',flag:'🇪🇸'},
    {id:'ucl',name:'Champions League',country:'Europa',flag:'🇪🇺'}
  ];

  const teams = {
    cam:{name:'Atlético-MG',short:'CAM',color:'#151515',form:[1,1,0,1,1],rating:82,atk:84,def:79},
    fla:{name:'Flamengo',short:'FLA',color:'#c91c28',form:[1,0,1,1,1],rating:86,atk:88,def:82},
    pal:{name:'Palmeiras',short:'PAL',color:'#176b45',form:[1,1,1,0,1],rating:87,atk:85,def:88},
    cru:{name:'Cruzeiro',short:'CRU',color:'#3156b7',form:[0,1,1,0,0],rating:78,atk:77,def:79},
    cor:{name:'Corinthians',short:'COR',color:'#30343b',form:[0,1,0,1,0],rating:77,atk:76,def:78},
    gre:{name:'Grêmio',short:'GRE',color:'#44a3e0',form:[1,0,0,1,0],rating:76,atk:75,def:77},
    mci:{name:'Manchester City',short:'MCI',color:'#60a5fa',form:[1,1,1,1,0],rating:91,atk:93,def:88},
    ars:{name:'Arsenal',short:'ARS',color:'#dc2626',form:[1,1,0,1,1],rating:89,atk:88,def:90},
    liv:{name:'Liverpool',short:'LIV',color:'#b91c1c',form:[1,0,1,1,1],rating:88,atk:90,def:85},
    che:{name:'Chelsea',short:'CHE',color:'#1d4ed8',form:[0,1,1,0,1],rating:83,atk:84,def:81},
    rma:{name:'Real Madrid',short:'RMA',color:'#d8dce6',form:[1,1,1,1,1],rating:92,atk:93,def:90},
    bar:{name:'Barcelona',short:'BAR',color:'#7c3aed',form:[1,1,0,1,1],rating:90,atk:92,def:86},
    atm:{name:'Atlético de Madrid',short:'ATM',color:'#e11d48',form:[1,0,1,1,0],rating:86,atk:84,def:88},
    sev:{name:'Sevilla',short:'SEV',color:'#f8fafc',form:[0,0,1,0,1],rating:79,atk:78,def:80},
    psg:{name:'Paris SG',short:'PSG',color:'#1e3a8a',form:[1,1,1,0,1],rating:89,atk:91,def:85},
    bay:{name:'Bayern',short:'BAY',color:'#ef4444',form:[1,1,0,1,1],rating:90,atk:92,def:87}
  };

  const matches = [
    {id:'m1',league:'bra',home:'cam',away:'fla',status:'live',minute:72,homeScore:1,awayScore:1,time:'21:30',stats:{pos:[48,52],shots:[13,8],on:[6,3],corners:[5,2],danger:[46,34],passes:[356,392],fouls:[11,13],xg:[1.42,.86],big:[4,2],press:[68,59]},events:[['12','goal','Hulk','Atlético-MG'],['39','card','Alan Franco','Atlético-MG'],['51','goal','Pedro','Flamengo'],['67','sub','Mudança ofensiva','Atlético-MG']]},
    {id:'m2',league:'bra',home:'pal',away:'cru',status:'upcoming',homeScore:null,awayScore:null,time:'21:30',stats:{pos:[56,44],shots:[15,9],on:[6,3],corners:[7,4],danger:[52,31],passes:[478,361],fouls:[9,12],xg:[1.71,.94],big:[5,2],press:[71,57]},events:[]},
    {id:'m3',league:'bra',home:'cor',away:'gre',status:'finished',homeScore:2,awayScore:0,time:'FT',stats:{pos:[52,48],shots:[11,7],on:[5,2],corners:[4,3],danger:[38,27],passes:[421,398],fouls:[14,10],xg:[1.34,.59],big:[3,1],press:[62,51]},events:[['31','goal','Yuri Alberto','Corinthians'],['78','goal','Garro','Corinthians']]},
    {id:'m4',league:'eng',home:'mci',away:'ars',status:'upcoming',homeScore:null,awayScore:null,time:'20:45',stats:{pos:[59,41],shots:[16,12],on:[7,5],corners:[6,5],danger:[55,47],passes:[552,421],fouls:[8,10],xg:[1.83,1.41],big:[5,4],press:[76,72]},events:[]},
    {id:'m5',league:'eng',home:'liv',away:'che',status:'upcoming',homeScore:null,awayScore:null,time:'18:30',stats:{pos:[54,46],shots:[17,10],on:[7,4],corners:[8,4],danger:[58,39],passes:[493,445],fouls:[11,9],xg:[1.96,1.12],big:[6,3],press:[78,64]},events:[]},
    {id:'m6',league:'esp',home:'rma',away:'bar',status:'upcoming',homeScore:null,awayScore:null,time:'21:00',stats:{pos:[49,51],shots:[15,14],on:[6,6],corners:[5,6],danger:[50,52],passes:[506,523],fouls:[10,12],xg:[1.78,1.69],big:[5,5],press:[74,75]},events:[]},
    {id:'m7',league:'esp',home:'atm',away:'sev',status:'finished',homeScore:1,awayScore:0,time:'FT',stats:{pos:[46,54],shots:[10,12],on:[4,3],corners:[3,6],danger:[34,41],passes:[365,438],fouls:[15,11],xg:[1.08,.91],big:[2,2],press:[63,58]},events:[['64','goal','Griezmann','Atlético de Madrid']]},
    {id:'m8',league:'ucl',home:'psg',away:'bay',status:'upcoming',homeScore:null,awayScore:null,time:'22:00',stats:{pos:[51,49],shots:[14,16],on:[6,7],corners:[5,6],danger:[48,54],passes:[499,482],fouls:[9,10],xg:[1.57,1.81],big:[4,5],press:[70,75]},events:[]}
  ];

  const standings = {
    bra:[['pal',52,24],['fla',49,24],['cam',45,24],['cru',41,24],['cor',35,24],['gre',33,24]],
    eng:[['mci',15,6],['ars',14,6],['liv',13,6],['che',10,6]],
    esp:[['rma',16,6],['bar',15,6],['atm',12,6],['sev',7,6]],
    ucl:[['bay',12,5],['rma',12,5],['psg',10,5],['mci',9,5]]
  };

  function poisson(lambda,k){ let p=Math.exp(-lambda); for(let i=1;i<=k;i++)p*=lambda/i; return p; }
  function modelFor(match){
    const h=teams[match.home], a=teams[match.away], s=match.stats;
    const hForm=h.form.reduce((x,v)=>x+v,0)/h.form.length;
    const aForm=a.form.reduce((x,v)=>x+v,0)/a.form.length;
    const baseH = 1.18 + (h.atk-a.def)/45 + hForm*.34 + (s.xg[0]-1.2)*.22;
    const baseA = 1.02 + (a.atk-h.def)/45 + aForm*.31 + (s.xg[1]-1.1)*.22;
    const lh=clamp(baseH,.35,3.1), la=clamp(baseA,.3,2.9);
    let hw=0,d=0,aw=0; const matrix=[];
    for(let i=0;i<=6;i++){matrix[i]=[];for(let j=0;j<=6;j++){const p=poisson(lh,i)*poisson(la,j);matrix[i][j]=p;if(i>j)hw+=p;else if(i===j)d+=p;else aw+=p;}}
    const total=hw+d+aw; hw/=total;d/=total;aw/=total;
    let best=[0,0,0]; for(let i=0;i<=5;i++)for(let j=0;j<=5;j++)if(matrix[i][j]>best[2])best=[i,j,matrix[i][j]];
    const pressureH=clamp((s.press[0]*.45+s.danger[0]*.35+s.on[0]*2.2),0,100);
    const pressureA=clamp((s.press[1]*.45+s.danger[1]*.35+s.on[1]*2.2),0,100);
    const attackEdge=clamp(50+(h.atk-a.atk)*2+(s.xg[0]-s.xg[1])*12,8,92);
    const control=clamp(50+(s.pos[0]-s.pos[1])*.7+(s.passes[0]-s.passes[1])*.03,10,90);
    const intensity=clamp((s.press[0]+s.press[1]+s.danger[0]+s.danger[1])/2,35,92);
    return {lh,la,hw:hw*100,d:d*100,aw:aw*100,best,pressureH,pressureA,attackEdge,control,intensity};
  }

  function crest(id,lg=false){ const t=teams[id]; return `<span class="${lg?'crest-lg':'crest'}" style="background:${t.color}">${esc(t.short)}</span>`; }
  function formDots(arr){ return arr.map(v=>`<span style="display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:3px;background:${v?'var(--success)':'var(--muted-2)'}"></span>`).join(''); }
  function statusLabel(m){ if(m.status==='live') return `${m.minute}'`; if(m.status==='finished') return 'ENC'; return m.time; }
  function isFav(id){return state.favorites.includes(id)}
  function toggleFav(id){ state.favorites = isFav(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id]; localStorage.setItem('ms_favorites',JSON.stringify(state.favorites)); toast(isFav(id)?'Adicionado aos favoritos':'Removido dos favoritos'); render(); }
  function toast(msg){ const root=$('#toast-root'); root.innerHTML=`<div class="toast">${esc(msg)}</div>`; setTimeout(()=>root.innerHTML='',1700); }

  function header({search=true}={}){
    return `<header class="topbar"><div class="brand-row"><div class="brand" data-route="home"><div class="brand-mark">M</div><div><div class="brand-title">MatchScope</div><div class="brand-sub">Futebol • dados • inteligência</div></div></div><div class="top-actions"><button class="icon-btn" data-route="favorites" aria-label="Favoritos">☆</button><button class="icon-btn" data-route="settings" aria-label="Ajustes">⚙</button></div></div>${search?`<div class="search-wrap"><label class="searchbox"><span>⌕</span><input id="global-search" placeholder="Buscar time ou competição" value="${esc(state.query)}" /></label></div>`:''}</header>`;
  }
  function nav(){ const items=[['home','▦','Jogos'],['live','●','Ao vivo'],['analysis','◈','Análises'],['competitions','◎','Competições'],['favorites','☆','Favoritos']]; return `<nav class="bottom-nav"><div class="bottom-inner">${items.map(([r,i,l])=>`<button class="nav-btn ${state.route===r?'active':''}" data-route="${r}"><span class="nav-icon">${i}</span><span>${l}</span></button>`).join('')}</div></nav>`; }
  function shell(body,{search=true,navBar=true}={}){ return `${header({search})}<main class="content">${body}</main>${navBar?nav():''}`; }

  function dateStrip(){ const labels=[['SEG','07'],['TER','08'],['HOJE','09'],['QUI','10'],['SEX','11']]; return `<div class="date-strip">${labels.map((d,i)=>`<button class="date-pill ${i===2+state.dateIndex?'active':''}" data-date="${i-2}"><div class="d1">${d[0]}</div><div class="d2">${d[1]}</div></button>`).join('')}</div>`; }

  function leagueBlock(league, rows){
    return `<section class="league-card card"><div class="league-head" data-competition="${league.id}"><div class="league-left"><div class="league-icon">${league.flag}</div><div><div class="league-name">${esc(league.name)}</div><div class="league-country">${esc(league.country)}</div></div></div><div class="league-more">Tabela ›</div></div>${rows.map(matchRow).join('')}</section>`;
  }
  function matchRow(m){ const h=teams[m.home],a=teams[m.away],mod=modelFor(m); const scoreH=m.homeScore??'–',scoreA=m.awayScore??'–'; return `<article class="match-row show-fav" data-match="${m.id}"><div class="match-time ${m.status==='live'?'live':''}">${statusLabel(m)}</div><div class="teams"><div class="team-line">${crest(m.home)}<span class="team-name">${esc(h.name)}</span></div><div class="team-line">${crest(m.away)}<span class="team-name">${esc(a.name)}</span></div></div><div class="score-stack"><span>${scoreH}</span><span>${scoreA}</span></div><button class="fav-star icon-btn" style="width:28px;height:28px;border:0;background:transparent" data-fav="${m.id}">${isFav(m.id)?'★':'☆'}</button><div class="match-insight"><span class="micro-tag"><strong>${round(mod.lh+mod.la,1)}</strong> gols proj.</span><span class="micro-tag"><strong>${Math.round(mod.intensity)}</strong> intensidade</span>${m.status==='live'?`<span class="micro-tag"><strong>${Math.round(mod.pressureH)}</strong> pressão casa</span>`:''}</div></article>`; }

  function home(){
    let filtered=matches.filter(m=>state.filter==='all'||m.status===state.filter);
    if(state.query){ const q=state.query.toLowerCase(); filtered=filtered.filter(m=>teams[m.home].name.toLowerCase().includes(q)||teams[m.away].name.toLowerCase().includes(q)||leagues.find(l=>l.id===m.league).name.toLowerCase().includes(q)); }
    const groups=leagues.map(l=>[l,filtered.filter(m=>m.league===l.id)]).filter(x=>x[1].length);
    const body=`<section class="section"><div class="hero card"><div class="hero-kicker">MatchScope V2</div><div class="hero-title">O jogo explicado em segundos.</div><div class="hero-copy">Placar, contexto e análise aprofundada com uma interface construída para leitura rápida.</div><div class="hero-grid"><div class="hero-stat"><b>${matches.length}</b><span>jogos demonstrativos</span></div><div class="hero-stat"><b>${matches.filter(m=>m.status==='live').length}</b><span>ao vivo agora</span></div><div class="hero-stat"><b>12+</b><span>métricas por jogo</span></div></div></div></section><div class="notice"><b>Modo demonstração.</b> O aplicativo está totalmente navegável e analítico. Para placares reais automáticos, conecte depois um provedor de dados esportivos.</div>${dateStrip()}<div class="chips"><button class="chip ${state.filter==='all'?'active':''}" data-filter="all">Todos</button><button class="chip ${state.filter==='live'?'active':''}" data-filter="live">● Ao vivo</button><button class="chip ${state.filter==='upcoming'?'active':''}" data-filter="upcoming">Próximos</button><button class="chip ${state.filter==='finished'?'active':''}" data-filter="finished">Encerrados</button></div><section class="section" style="margin-top:12px">${groups.length?groups.map(([l,r])=>leagueBlock(l,r)).join(''):`<div class="empty card"><div class="empty-icon">⌕</div><div class="empty-title">Nada encontrado</div><div class="empty-copy">Tente outro time, competição ou filtro.</div></div>`}</section>`;
    return shell(body);
  }

  function live(){ const rows=matches.filter(m=>m.status==='live'); const body=`<div class="page-title-row"><div><div class="page-title">Ao vivo</div><div class="page-sub">Partidas em andamento</div></div></div>${rows.length?rows.map(m=>{const l=leagues.find(x=>x.id===m.league);return leagueBlock(l,[m]);}).join(''):`<div class="empty card"><div class="empty-icon">●</div><div class="empty-title">Nenhum jogo ao vivo</div><div class="empty-copy">Quando uma partida começar ela aparece aqui.</div></div>`}`; return shell(body); }

  function matchPage(){
    const m=matches.find(x=>x.id===state.matchId)||matches[0],h=teams[m.home],a=teams[m.away],l=leagues.find(x=>x.id===m.league),mod=modelFor(m);
    const hero=`<div class="page-title-row"><button class="back-btn" data-route="home">‹</button><div><div class="page-title">Partida</div><div class="page-sub">${esc(l.name)}</div></div></div><section class="match-hero card"><div class="match-meta">${l.flag} ${esc(l.name)} · ${m.status==='live'?`AO VIVO · ${m.minute}'`:m.status==='finished'?'ENCERRADO':m.time}</div><div class="scoreboard"><div class="team-hero">${crest(m.home,true)}<div class="team-hero-name">${esc(h.name)}</div></div><div><div class="big-score">${m.homeScore??'–'} : ${m.awayScore??'–'}</div><div class="score-status">${m.status==='live'?'● AO VIVO':m.status==='finished'?'FINAL':'PRÓXIMO'}</div></div><div class="team-hero">${crest(m.away,true)}<div class="team-hero-name">${esc(a.name)}</div></div></div><div style="display:flex;justify-content:center;margin-top:12px"><button class="chip ${isFav(m.id)?'active':''}" data-fav="${m.id}">${isFav(m.id)?'★ Favoritado':'☆ Favoritar'}</button></div></section>`;
    const tabs=['summary','stats','analysis','lineups','h2h']; const labels={summary:'Resumo',stats:'Estatísticas',analysis:'Análise',lineups:'Escalações',h2h:'H2H'}; const tabbar=`<div class="tabs">${tabs.map(t=>`<button class="tab ${state.tab===t?'active':''}" data-tab="${t}">${labels[t]}</button>`).join('')}</div>`;
    let body=''; if(state.tab==='summary')body=summaryTab(m,mod); if(state.tab==='stats')body=statsTab(m); if(state.tab==='analysis')body=analysisTab(m,mod); if(state.tab==='lineups')body=lineupsTab(m); if(state.tab==='h2h')body=h2hTab(m);
    return shell(hero+tabbar+body,{search:false});
  }
  function summaryTab(m,mod){
    const h=teams[m.home],a=teams[m.away]; return `<section class="section"><div class="section-head"><div class="section-title">Leitura rápida</div><span class="badge live">◈ modelo MatchScope</span></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Equilíbrio da partida</div><div class="analysis-desc">Combina força dos times, forma recente e produção ofensiva.</div></div><div class="analysis-score">${pct(mod.attackEdge)}</div></div><div class="dual-meter"><div class="bar left"><i style="width:${mod.attackEdge}%"></i></div><span>força ofensiva</span><div class="bar right"><i style="width:${100-mod.attackEdge}%"></i></div></div></div><div class="section-head" style="margin-top:14px"><div class="section-title">Probabilidades estatísticas</div></div><div class="prob-grid"><div class="prob ${mod.hw>mod.d&&mod.hw>mod.aw?'primary':''}"><b>${pct(mod.hw)}</b><span>${esc(h.short)}</span></div><div class="prob ${mod.d>mod.hw&&mod.d>mod.aw?'primary':''}"><b>${pct(mod.d)}</b><span>Empate</span></div><div class="prob ${mod.aw>mod.hw&&mod.aw>mod.d?'primary':''}"><b>${pct(mod.aw)}</b><span>${esc(a.short)}</span></div></div><div class="notice" style="margin-top:10px">Probabilidades são uma <b>estimativa esportiva</b> do modelo e não representam garantia de resultado.</div><div class="section-head" style="margin-top:14px"><div class="section-title">Eventos</div></div><div class="card" style="padding:13px">${m.events.length?`<div class="timeline">${m.events.map(e=>`<div class="event ${e[1]==='goal'?'goal':''}"><div class="event-time">${e[0]}'</div><div class="event-text"><b>${e[1]==='goal'?'⚽':e[1]==='card'?'▰':'↔'} ${esc(e[2])}</b> · ${esc(e[3])}</div></div>`).join('')}</div>`:`<div class="empty" style="padding:15px"><div class="empty-copy">Eventos ficam disponíveis quando a partida começa.</div></div>`}</div></section>`; }
  function statsTab(m){ const s=m.stats; const rows=[['Posse',s.pos[0]+'%',s.pos[1]+'%',s.pos[0],s.pos[1]],['Finalizações',s.shots[0],s.shots[1],s.shots[0],s.shots[1]],['No alvo',s.on[0],s.on[1],s.on[0],s.on[1]],['xG estimado',round(s.xg[0],2),round(s.xg[1],2),s.xg[0],s.xg[1]],['Grandes chances',s.big[0],s.big[1],s.big[0],s.big[1]],['Escanteios',s.corners[0],s.corners[1],s.corners[0],s.corners[1]],['Ataques perigosos',s.danger[0],s.danger[1],s.danger[0],s.danger[1]],['Passes',s.passes[0],s.passes[1],s.passes[0],s.passes[1]],['Faltas',s.fouls[0],s.fouls[1],s.fouls[0],s.fouls[1]]]; return `<section class="section"><div class="card" style="padding:14px">${rows.map(r=>{const total=Number(r[3])+Number(r[4])||1;return `<div class="stat-row"><div class="v">${r[1]}</div><div class="mid">${r[0]}</div><div class="v">${r[2]}</div><div class="stat-bars"><i style="width:${r[3]/total*100}%;justify-self:end"></i><i style="width:${r[4]/total*100}%"></i></div></div>`}).join('')}</div></section>`; }
  function sparkline(values){ const w=320,h=80,p=6; const min=Math.min(...values),max=Math.max(...values); const pts=values.map((v,i)=>`${p+i*(w-2*p)/(values.length-1)},${h-p-(v-min)/(max-min||1)*(h-2*p)}`).join(' '); return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6ee7b7"/><stop offset="1" stop-color="#38bdf8"/></linearGradient></defs><polyline points="${pts}" fill="none" stroke="url(#g)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><line x1="0" y1="${h/2}" x2="${w}" y2="${h/2}" stroke="rgba(255,255,255,.06)"/></svg>`; }
  function analysisTab(m,mod){ const h=teams[m.home],a=teams[m.away],s=m.stats; const momentum=[43,48,54,61,58,67,72,64,59,71,75,69]; return `<section class="section"><div class="section-head"><div class="section-title">Modelo de resultado</div><div class="section-note">Poisson + contexto</div></div><div class="prob-grid"><div class="prob ${mod.hw>mod.d&&mod.hw>mod.aw?'primary':''}"><b>${pct(mod.hw)}</b><span>${esc(h.name)}</span></div><div class="prob"><b>${pct(mod.d)}</b><span>Empate</span></div><div class="prob ${mod.aw>mod.hw&&mod.aw>mod.d?'primary':''}"><b>${pct(mod.aw)}</b><span>${esc(a.name)}</span></div></div><div class="analysis-card card" style="margin-top:10px"><div class="analysis-top"><div><div class="analysis-title">Placar modal</div><div class="analysis-desc">Resultado individual com maior massa no modelo.</div></div><div class="analysis-score">${mod.best[0]}–${mod.best[1]}</div></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Pressão ofensiva</div><div class="analysis-desc">Pressão, chegadas perigosas e finalizações no alvo.</div></div><div class="analysis-score">${Math.round(mod.pressureH)} / ${Math.round(mod.pressureA)}</div></div><div class="dual-meter"><div class="bar left"><i style="width:${mod.pressureH}%"></i></div><span>pressão</span><div class="bar right"><i style="width:${mod.pressureA}%"></i></div></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Controle territorial</div><div class="analysis-desc">Posse e volume de passes ajustados.</div></div><div class="analysis-score">${pct(mod.control)}</div></div><div class="meter"><i style="width:${mod.control}%"></i></div></div><div class="analysis-card card"><div class="analysis-top"><div><div class="analysis-title">Intensidade do confronto</div><div class="analysis-desc">Quanto o jogo exige transições e ações de pressão.</div></div><div class="analysis-score">${Math.round(mod.intensity)}</div></div><div class="meter"><i style="width:${mod.intensity}%"></i></div></div><div class="section-head" style="margin-top:14px"><div class="section-title">Momentum</div><div class="section-note">últimos blocos</div></div><div class="card" style="padding:12px">${sparkline(momentum)}<div class="legend-row"><span>${esc(h.short)} <b>${s.danger[0]}</b></span><span>ataques perigosos</span><span>${esc(a.short)} <b>${s.danger[1]}</b></span></div></div><div class="section-head" style="margin-top:14px"><div class="section-title">Forma recente</div></div><div class="card" style="padding:13px"><div class="settings-row"><div><div class="settings-title">${esc(h.name)}</div><div class="settings-copy">${formDots(h.form)}</div></div><b>${h.form.reduce((x,v)=>x+v,0)}/5</b></div><div class="settings-row"><div><div class="settings-title">${esc(a.name)}</div><div class="settings-copy">${formDots(a.form)}</div></div><b>${a.form.reduce((x,v)=>x+v,0)}/5</b></div></div><div class="notice" style="margin-top:10px">A análise é informativa e esportiva. O MatchScope não fornece odds, apostas ou recomendações financeiras.</div></section>`; }
  function lineupsTab(m){ const home=['Goleiro','Lateral D.','Zagueiro','Zagueiro','Lateral E.','Volante','Meia','Meia','Ponta D.','Centroavante','Ponta E.']; const away=['Goleiro','Lateral D.','Zagueiro','Zagueiro','Lateral E.','Volante','Meia','Meia','Ponta D.','Centroavante','Ponta E.']; return `<section class="section"><div class="card" style="padding:14px"><div class="section-head"><div class="section-title">Formação provável</div><div class="section-note">4-3-3</div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:14px"><div>${home.map((x,i)=>`<div class="settings-row"><span class="badge">${i+1}</span><div style="flex:1;margin-left:8px"><div class="settings-title">${esc(x)}</div><div class="settings-copy">${esc(teams[m.home].name)}</div></div></div>`).join('')}</div><div>${away.map((x,i)=>`<div class="settings-row"><span class="badge">${i+1}</span><div style="flex:1;margin-left:8px"><div class="settings-title">${esc(x)}</div><div class="settings-copy">${esc(teams[m.away].name)}</div></div></div>`).join('')}</div></div></div></section>`; }
  function h2hTab(m){ const h=teams[m.home],a=teams[m.away]; const sample=[[h.name,2,1,a.name],[a.name,1,1,h.name],[h.name,0,0,a.name],[a.name,1,2,h.name],[h.name,3,1,a.name]]; return `<section class="section"><div class="section-head"><div class="section-title">Últimos confrontos</div></div><div class="card">${sample.map((x,i)=>`<div class="settings-row" style="padding:12px"><div style="width:28px;color:var(--muted);font-size:10px">${i+1}</div><div style="flex:1;font-size:11px">${esc(x[0])}</div><b>${x[1]} : ${x[2]}</b><div style="flex:1;text-align:right;font-size:11px">${esc(x[3])}</div></div>`).join('')}</div></section>`; }

  function analysisHub(){ const top=matches.map(m=>({m,mod:modelFor(m)})).sort((a,b)=>b.mod.intensity-a.mod.intensity); const body=`<div class="page-title-row"><div><div class="page-title">Análises</div><div class="page-sub">Leitura avançada dos jogos</div></div></div><section class="hero card"><div class="hero-kicker">Central de inteligência</div><div class="hero-title">Mais contexto. Menos ruído.</div><div class="hero-copy">Compare pressão, forma, força ofensiva, equilíbrio e cenários estatísticos de cada confronto.</div></section><div class="section-head" style="margin-top:16px"><div class="section-title">Jogos mais intensos</div></div>${top.slice(0,5).map(({m,mod})=>`<div class="analysis-card card" data-match="${m.id}"><div class="analysis-top"><div><div class="analysis-title">${esc(teams[m.home].name)} × ${esc(teams[m.away].name)}</div><div class="analysis-desc">${esc(leagues.find(l=>l.id===m.league).name)}</div></div><div class="analysis-score">${Math.round(mod.intensity)}</div></div><div class="meter"><i style="width:${mod.intensity}%"></i></div></div>`).join('')}<div class="section-head" style="margin-top:16px"><div class="section-title">Laboratório manual</div><div class="section-note">sem internet</div></div>${manualLab()}`; return shell(body); }

  function manualLab(){ return `<div class="input-card card"><div class="form-grid"><div class="field"><label>Time A</label><input id="lab-a" value="Time A" /></div><div class="field"><label>Time B</label><input id="lab-b" value="Time B" /></div><div class="field"><label>Força ofensiva A (0–100)</label><input id="lab-atk-a" type="number" min="0" max="100" value="82" /></div><div class="field"><label>Força ofensiva B (0–100)</label><input id="lab-atk-b" type="number" min="0" max="100" value="78" /></div><div class="field"><label>Defesa A (0–100)</label><input id="lab-def-a" type="number" min="0" max="100" value="80" /></div><div class="field"><label>Defesa B (0–100)</label><input id="lab-def-b" type="number" min="0" max="100" value="76" /></div><div class="field"><label>Gols médios A</label><input id="lab-gf-a" type="number" step="0.1" value="1.7" /></div><div class="field"><label>Gols médios B</label><input id="lab-gf-b" type="number" step="0.1" value="1.4" /></div></div><button class="primary-btn" id="run-lab">Gerar análise</button><div id="lab-result"></div></div>`; }

  function competitions(){ const body=`<div class="page-title-row"><div><div class="page-title">Competições</div><div class="page-sub">Tabelas e jogos</div></div></div><div class="comp-grid">${leagues.map(l=>`<button class="comp-card card" data-competition="${l.id}" style="text-align:left;color:inherit;border:1px solid var(--line)"><div class="comp-flag">${l.flag}</div><div class="comp-name">${esc(l.name)}</div><div class="comp-meta">${standings[l.id].length} clubes no demo</div></button>`).join('')}</div>`; return shell(body); }
  function competitionPage(){ const l=leagues.find(x=>x.id===state.competitionId)||leagues[0], table=standings[l.id]; const body=`<div class="page-title-row"><button class="back-btn" data-route="competitions">‹</button><div><div class="page-title">${l.flag} ${esc(l.name)}</div><div class="page-sub">${esc(l.country)}</div></div></div><div class="tabs"><button class="tab active">Classificação</button><button class="tab">Jogos</button><button class="tab">Forma</button></div><section class="standings card"><div class="table-head"><span>#</span><span>Time</span><span>J</span><span>SG</span><span style="text-align:right">PTS</span></div>${table.map((r,i)=>{const t=teams[r[0]],gd=Math.max(-5,Math.round((t.atk-t.def)/2+i%3));return `<div class="table-row"><span class="rank ${i<4?'top':''}">${i+1}</span><span class="table-team">${crest(r[0])}<span class="team-name">${esc(t.name)}</span></span><span>${r[2]}</span><span>${gd>0?'+':''}${gd}</span><span class="pts">${r[1]}</span></div>`}).join('')}</section><div class="section-head" style="margin-top:16px"><div class="section-title">Jogos</div></div>${leagueBlock(l,matches.filter(m=>m.league===l.id))}`; return shell(body,{search:false}); }
  function favorites(){ const rows=matches.filter(m=>isFav(m.id)); const body=`<div class="page-title-row"><div><div class="page-title">Favoritos</div><div class="page-sub">Seus jogos salvos</div></div></div>${rows.length?rows.map(m=>leagueBlock(leagues.find(l=>l.id===m.league),[m])).join(''):`<div class="empty card"><div class="empty-icon">☆</div><div class="empty-title">Nada favoritado ainda</div><div class="empty-copy">Toque na estrela de uma partida para mantê-la aqui.</div></div>`}`; return shell(body); }
  function settings(){ const body=`<div class="page-title-row"><button class="back-btn" data-route="home">‹</button><div><div class="page-title">Ajustes</div><div class="page-sub">Preferências do MatchScope</div></div></div><div class="card" style="padding:0 14px"><div class="settings-row"><div><div class="settings-title">Dados demonstrativos</div><div class="settings-copy">Base local para o app funcionar sem internet.</div></div><div class="switch on"><i></i></div></div><div class="settings-row"><div><div class="settings-title">Modo compacto</div><div class="settings-copy">Mais jogos visíveis por tela.</div></div><button class="switch ${state.compact?'on':''}" id="toggle-compact"><i></i></button></div><div class="settings-row"><div><div class="settings-title">Tema</div><div class="settings-copy">Interface escura otimizada para leitura.</div></div><span class="badge">Escuro</span></div><div class="settings-row"><div><div class="settings-title">Versão</div><div class="settings-copy">MatchScope V2.0.0</div></div><span class="badge">Android</span></div></div><div class="notice" style="margin-top:12px"><b>Dados reais:</b> a arquitetura já separa a camada de dados da interface. Um provedor esportivo pode ser conectado sem refazer as telas.</div>`; return shell(body,{search:false,navBar:false}); }

  function runLab(){ const va=id=>parseFloat($(id).value)||0, nameA=$('#lab-a').value||'Time A', nameB=$('#lab-b').value||'Time B'; const atkA=va('#lab-atk-a'),atkB=va('#lab-atk-b'),defA=va('#lab-def-a'),defB=va('#lab-def-b'),gfA=va('#lab-gf-a'),gfB=va('#lab-gf-b'); const lh=clamp(.55+gfA*.55+(atkA-defB)/70,.25,3.2),la=clamp(.45+gfB*.55+(atkB-defA)/70,.25,3.0); let hw=0,d=0,aw=0,b=[0,0,0]; for(let i=0;i<7;i++)for(let j=0;j<7;j++){const p=poisson(lh,i)*poisson(la,j);if(i>j)hw+=p;else if(i===j)d+=p;else aw+=p;if(p>b[2])b=[i,j,p];} const t=hw+d+aw; hw=hw/t*100;d=d/t*100;aw=aw/t*100; $('#lab-result').innerHTML=`<div class="divider"></div><div class="section-title">Resultado da análise</div><div class="prob-grid" style="margin-top:10px"><div class="prob ${hw>d&&hw>aw?'primary':''}"><b>${pct(hw)}</b><span>${esc(nameA)}</span></div><div class="prob"><b>${pct(d)}</b><span>Empate</span></div><div class="prob ${aw>hw&&aw>d?'primary':''}"><b>${pct(aw)}</b><span>${esc(nameB)}</span></div></div><div class="analysis-card card" style="margin-top:10px"><div class="analysis-top"><div><div class="analysis-title">Placar modal</div><div class="analysis-desc">Cenário de maior probabilidade individual.</div></div><div class="analysis-score">${b[0]}–${b[1]}</div></div></div><div class="notice">Estimativa estatística esportiva; não é garantia de resultado.</div>`; }

  function render(){ const app=$('#app'); if(!app)return; let html=''; if(state.route==='home')html=home(); else if(state.route==='live')html=live(); else if(state.route==='match')html=matchPage(); else if(state.route==='analysis')html=analysisHub(); else if(state.route==='competitions')html=competitions(); else if(state.route==='competition')html=competitionPage(); else if(state.route==='favorites')html=favorites(); else if(state.route==='settings')html=settings(); else html=home(); app.innerHTML=html; bind(); }
  function snapshot(){ return {route:state.route,matchId:state.matchId,competitionId:state.competitionId,tab:state.tab}; }
  function pushHistory(){ if(typeof history!=='undefined') history.pushState(snapshot(),''); }
  function go(route){ state.route=route; if(route!=='match')state.tab='summary'; pushHistory(); if(typeof window!=='undefined')window.scrollTo(0,0); render(); }
  function bind(){
    $$('[data-route]').forEach(el=>el.onclick=()=>go(el.dataset.route));
    $$('[data-match]').forEach(el=>el.onclick=e=>{if(e.target.closest('[data-fav]'))return;state.matchId=el.dataset.match;state.route='match';state.tab='summary';pushHistory();window.scrollTo(0,0);render();});
    $$('[data-fav]').forEach(el=>el.onclick=e=>{e.stopPropagation();toggleFav(el.dataset.fav)});
    $$('[data-filter]').forEach(el=>el.onclick=()=>{state.filter=el.dataset.filter;render()});
    $$('[data-date]').forEach(el=>el.onclick=()=>{state.dateIndex=Number(el.dataset.date);toast(state.dateIndex===0?'Hoje selecionado':'Demo: agenda ilustrativa');render()});
    $$('[data-tab]').forEach(el=>el.onclick=()=>{state.tab=el.dataset.tab;render()});
    $$('[data-competition]').forEach(el=>el.onclick=()=>{state.competitionId=el.dataset.competition;state.route='competition';pushHistory();window.scrollTo(0,0);render()});
    const search=$('#global-search'); if(search){search.oninput=()=>{state.query=search.value; const pos=search.selectionStart||state.query.length; clearTimeout(search._t); search._t=setTimeout(()=>{render(); const n=$('#global-search'); if(n){n.focus(); try{n.setSelectionRange(pos,pos)}catch(e){}}},220)}}
    const lab=$('#run-lab'); if(lab)lab.onclick=runLab;
    const compact=$('#toggle-compact'); if(compact)compact.onclick=()=>{state.compact=!state.compact;localStorage.setItem('ms_compact',state.compact?'1':'0');toast(state.compact?'Modo compacto ativado':'Modo compacto desativado');render()};
  }

  const rootGlobal = typeof window !== 'undefined' ? window : globalThis;
  rootGlobal.MatchScope = {state,matches,teams,leagues,modelFor,poisson,render};
  if (typeof window !== 'undefined') {
    history.replaceState(snapshot(),'');
    window.addEventListener('popstate', e => {
      const x=e.state||{route:'home'}; state.route=x.route||'home'; state.matchId=x.matchId||null; state.competitionId=x.competitionId||null; state.tab=x.tab||'summary'; render();
    });
  }
  if (typeof document !== 'undefined') render();
})();
