/* MatchScope native/offline adapter.
   If MATCHSCOPE_API_BASE is set to an https URL, API requests are sent there.
   Otherwise a local on-device demo API is used so the app remains executable offline. */
(() => {
  const API_BASE = (window.MATCHSCOPE_API_BASE || '').replace(/\/$/, '');
  const native = location.protocol === 'file:';
  if (!native && !API_BASE) return;
  const originalFetch = window.fetch.bind(window);
  const key='ms_native_db_v1';
  const now=()=>new Date().toISOString();
  const read=()=>{try{return JSON.parse(localStorage.getItem(key))||seed()}catch{return seed()}};
  const write=db=>localStorage.setItem(key,JSON.stringify(db));
  const seed=()=>({users:[{id:1,name:'Usuário Demo',email:'demo@matchscope.local',password:'demo123',is_premium:true,is_admin:false}],token:'',history:[],notifications:[{id:1,title:'Bem-vindo ao MatchScope',body:'O modo local está ativo. Conecte um backend HTTPS para sincronização em nuvem.',created_at:now(),read:false}],teams:[
    {id:1,name:'Atlético-MG',short_name:'CAM',rating:1640,form:2.0,gf:1.55,ga:1.15},
    {id:2,name:'Santos',short_name:'SAN',rating:1580,form:1.75,gf:1.45,ga:1.25},
    {id:3,name:'Palmeiras',short_name:'PAL',rating:1740,form:2.25,gf:1.85,ga:.90},
    {id:4,name:'Flamengo',short_name:'FLA',rating:1760,form:2.35,gf:1.95,ga:.88},
    {id:5,name:'São Paulo',short_name:'SAO',rating:1600,form:1.65,gf:1.35,ga:1.18},
    {id:6,name:'Grêmio',short_name:'GRE',rating:1540,form:1.35,gf:1.28,ga:1.42}
  ],matches:[
    {id:101,competition_code:'BRA',competition_name:'Campeonato Brasileiro',utc_date:new Date(Date.now()+3*3600000).toISOString(),status:'SCHEDULED',home_name:'Atlético-MG',away_name:'Santos',home_score:null,away_score:null},
    {id:102,competition_code:'BRA',competition_name:'Campeonato Brasileiro',utc_date:new Date(Date.now()+6*3600000).toISOString(),status:'SCHEDULED',home_name:'Palmeiras',away_name:'São Paulo',home_score:null,away_score:null},
    {id:103,competition_code:'CONMEBOL',competition_name:'Competição Continental',utc_date:new Date(Date.now()+26*3600000).toISOString(),status:'SCHEDULED',home_name:'Flamengo',away_name:'Grêmio',home_score:null,away_score:null}
  ]});
  const db0=read(); if(!localStorage.getItem(key)) write(db0);
  const json=(d,status=200)=>Promise.resolve(new Response(JSON.stringify(d),{status,headers:{'Content-Type':'application/json'}}));
  const poisson=(l,k)=>Math.exp(-l)*Math.pow(l,k)/fact(k); const fact=n=>{let x=1;for(let i=2;i<=n;i++)x*=i;return x};
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const prand=l=>{const L=Math.exp(-l);let k=0,p=1;do{k++;p*=Math.random()}while(p>L);return k-1};
  function analyze(d,n=10000){
    const bh=(d.gfH+d.gaA)/2, ba=(d.gfA+d.gaH)/2, gap=clamp((d.ratingH-d.ratingA)/400,-1.2,1.2), fg=clamp((d.formH-d.formA)/3,-.6,.6);
    const hf=d.neutral?1:1.12, af=d.neutral?1:.92, xh=clamp(bh*hf*(1+.13*gap+.08*fg),.2,3.8), xa=clamp(ba*af*(1-.10*gap-.06*fg),.2,3.8);
    let h=0,dr=0,a=0,s=[]; for(let i=0;i<9;i++)for(let j=0;j<9;j++){const p=poisson(xh,i)*poisson(xa,j);s.push([i,j,p]);if(i>j)h+=p;else if(i===j)dr+=p;else a+=p}
    const t=h+dr+a;h/=t;dr/=t;a/=t;s.sort((x,y)=>y[2]-x[2]);let sh=0,sd=0,sa=0;for(let i=0;i<n;i++){const x=prand(xh),y=prand(xa);x>y?sh++:x===y?sd++:sa++}
    const spread=Math.max(h,dr,a)-Math.min(h,dr,a),confidence=spread<.14?'Baixa':spread<.28?'Média':'Alta',ins=[];
    if(!d.neutral)ins.push(`O mando de campo aumenta a projeção ofensiva de ${d.home}.`); if(Math.abs(d.ratingH-d.ratingA)>=80)ins.push(`O rating geral favorece ${d.ratingH>d.ratingA?d.home:d.away}.`); if(Math.abs(d.formH-d.formA)>=.35)ins.push(`A forma recente favorece ${d.formH>d.formA?d.home:d.away}.`); if(xh+xa<2.25)ins.push('A projeção aponta tendência de jogo mais fechado.'); else if(xh+xa>3)ins.push('A projeção aponta potencial de jogo mais aberto.'); ins.push('As probabilidades são estimativas estatísticas e não garantem o resultado.');
    return {home:+(h*100).toFixed(1),draw:+(dr*100).toFixed(1),away:+(a*100).toFixed(1),xh:+xh.toFixed(2),xa:+xa.toFixed(2),confidence,scores:s.slice(0,6).map(x=>({score:`${x[0]} × ${x[1]}`,p:+(x[2]*100).toFixed(1)})),sim:{h:sh,d:sd,a:sa,n},insights:ins,model_version:'MS-Poisson-2.1 Local'};
  }
  function team(db,name){return db.teams.find(t=>t.name===name)||{rating:1500,form:1.5,gf:1.3,ga:1.3}}
  window.fetch=async(input,opts={})=>{
    let url=typeof input==='string'?input:input.url;
    if(API_BASE && url.startsWith('/api/')) return originalFetch(API_BASE+url,opts);
    if(!url.startsWith('/api/')) return originalFetch(input,opts);
    const db=read(),path=url.split('?')[0],method=(opts.method||'GET').toUpperCase(),body=opts.body?JSON.parse(opts.body):{};
    if(path==='/api/me') return db.token?json(db.users[0]):json({detail:'Sessão não encontrada'},401);
    if(path==='/api/auth/login' || path==='/api/auth/register'){db.token='local-token';if(body.name)db.users[0].name=body.name;if(body.email)db.users[0].email=body.email;write(db);return json({token:db.token})}
    if(path==='/api/dashboard') return json({provider:{live:false},stats:{analyses:db.history.length,favorites:db.history.filter(x=>x.favorite).length,unread:db.notifications.filter(x=>!x.read).length},matches:db.matches,competitions:[{code:'BRA',name:'Campeonato Brasileiro',country:'Brasil'},{code:'CONMEBOL',name:'Competição Continental',country:'América do Sul'}]});
    if(path==='/api/teams') return json(db.teams);
    if(/^\/api\/teams\/\d+$/.test(path)){const id=+path.split('/').pop();return json({team:db.teams.find(x=>x.id===id)||db.teams[0]})}
    if(path==='/api/competitions')return json([{code:'BRA',name:'Campeonato Brasileiro'},{code:'CONMEBOL',name:'Competição Continental'}]);
    if(path.startsWith('/api/competitions/')){const code=decodeURIComponent(path.split('/').pop());return json({competition:{code,name:code==='BRA'?'Campeonato Brasileiro':'Competição Continental'},matches:db.matches.filter(x=>x.competition_code===code)})}
    if(/^\/api\/matches\/\d+\/preset$/.test(path)){const id=+path.split('/')[3],m=db.matches.find(x=>x.id===id)||db.matches[0],h=team(db,m.home_name),a=team(db,m.away_name);return json({match:m,home:h,away:a})}
    if(path==='/api/analyze'&&method==='POST'){const result=analyze(body,db.users[0].is_premium?50000:10000);if(db.token){db.history.unshift({id:Date.now(),home_name:body.home,away_name:body.away,result,created_at:now(),favorite:false});write(db)}return json({result})}
    if(path==='/api/history')return json(db.history);
    if(/^\/api\/history\/\d+\/favorite$/.test(path)){const id=+path.split('/')[3],h=db.history.find(x=>x.id===id);if(h)h.favorite=!h.favorite;write(db);return json({ok:true})}
    if(path==='/api/notifications')return json(db.notifications);
    if(path==='/api/notifications/read'){db.notifications.forEach(n=>n.read=true);write(db);return json({ok:true})}
    if(path==='/api/notifications/test'){db.notifications.unshift({id:Date.now(),title:'Alerta de teste',body:'Notificações locais funcionando.',created_at:now(),read:false});write(db);return json({ok:true})}
    if(path==='/api/provider/status')return json({configured:false,live:false});
    return json({detail:'Recurso indisponível no modo local'},404);
  };
})();
