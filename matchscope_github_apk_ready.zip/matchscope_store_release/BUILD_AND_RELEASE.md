# Build e release

## O que já está preparado
O pacote contém frontend, backend, projeto Android fonte, fonte iOS, ícones, screenshots/listagens e documentos de loja.

## Android
O projeto está configurado para `compileSdk = 36` e `targetSdk = 36`.
Use Android Studio/Gradle atual e JDK 17+.

1. Abra `android/` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Instale SDK 36/Build Tools 36.0.0 quando solicitado.
4. Execute em aparelho/emulador para validar.
5. Em Build > Generate Signed App Bundle, gere o `.aab` com sua chave de upload.

A chave de assinatura não é incluída no ZIP por segurança e deve pertencer ao titular da conta Google Play.

## iOS
A versão da App Store precisa ser compilada em macOS com Xcode 26+ e iOS 26 SDK+.
Os arquivos Swift, Info.plist, frontend e AppIcon estão no diretório `ios/MatchScope`.
Crie/abra um projeto iOS no Xcode com bundle id `com.matchscope.app`, adicione esses arquivos ao target, selecione seu Apple Developer Team, teste e use Product > Archive.

O certificado/perfil de assinatura Apple não é incluído porque é emitido para a conta do publicador.

## Backend
Hospede `backend/` em um host HTTPS. Configure as variáveis de ambiente descritas em `.env.example` e um banco persistente.
Para produção, é recomendável PostgreSQL em vez do SQLite local e um domínio como `https://api.seudominio.com`.

## Importante
A versão de loja deve ser comercializada como análise esportiva. O pacote não contém odds, carteira, depósitos, links de casas de aposta nem execução de apostas.
