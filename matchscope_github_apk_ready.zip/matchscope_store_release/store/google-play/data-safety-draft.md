# Rascunho — Segurança de dados Google Play

Revisar antes do envio, de acordo com o backend que for efetivamente hospedado.

Dados que a versão com conta pode coletar:
- e-mail e nome para criação da conta;
- histórico de análises e favoritos;
- dados técnicos mínimos de sessão no servidor.

Uso:
- autenticação;
- sincronização do histórico;
- funcionamento dos recursos do aplicativo.

Não declarar venda/compartilhamento de dados sem revisar todos os provedores efetivamente usados em produção.
