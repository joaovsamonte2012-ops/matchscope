# MatchScope — Inteligência do Futebol

**Descrição curta:** Estatísticas, simulações e análise de partidas em um só lugar.

## Descrição completa
MatchScope transforma dados de futebol em leituras claras e visuais. Compare equipes, acompanhe partidas, explore competições e rode modelos estatísticos para entender melhor cada confronto.

Recursos:
- probabilidades estatísticas de resultado;
- estimativa de gols esperados;
- placares mais prováveis;
- simulações Monte Carlo;
- forma recente e rating das equipes;
- histórico e favoritos;
- jogos e competições quando uma fonte licenciada estiver conectada.

As projeções são informativas e não garantem resultados. MatchScope é um aplicativo de análise esportiva e não oferece, intermedeia ou executa apostas.
