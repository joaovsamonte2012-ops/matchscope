# Rascunho — App Privacy

A versão com conta pode coletar:
- Contact Info: e-mail e nome, vinculados à conta;
- User Content / Other User Content: histórico de análises e favoritos, vinculados à conta;
- Identifiers: identificador interno da conta/sessão.

Finalidades: App Functionality e Account Management.

Revisar esta ficha após escolher hospedagem, analytics, crash reporting, notificações push e fornecedor de dados, pois SDKs de terceiros podem alterar as declarações obrigatórias.
